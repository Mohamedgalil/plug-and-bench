package org.ecore.component.componentParameter;

import org.ecore.service.parameterDefinition.ParameterDefinitionTypeConformance;

@SuppressWarnings("all")
public class ComponentParameterTypeConformance extends ParameterDefinitionTypeConformance {
}
