package org.ecore.component.componentParameter;

import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.ecore.base.basicAttributes.AttributeDefinition;
import org.ecore.base.basicAttributes.AttributeRefinement;
import org.ecore.component.componentParameter.AbstractParameterInstance;
import org.ecore.component.componentParameter.ComponentParameterBase;
import org.ecore.component.componentParameter.ExtendedParameter;
import org.ecore.component.componentParameter.InternalParameter;
import org.ecore.component.componentParameter.ParameterInstance;
import org.ecore.component.componentParameter.TriggerInstance;
import org.ecore.service.parameterDefinition.ParameterDefinition;
import org.ecore.service.parameterDefinition.ParameterDefinitionModelUtility;
import org.ecore.service.parameterDefinition.TriggerDefinition;

@SuppressWarnings("all")
public class ComponentParameterModelUtility extends ParameterDefinitionModelUtility {
  public EList<AttributeDefinition> getReferencedAttributes(final AbstractParameterInstance instance) {
    if ((instance instanceof ParameterInstance)) {
      ParameterDefinition _parameterDef = ((ParameterInstance)instance).getParameterDef();
      EList<AttributeDefinition> _attributes = null;
      if (_parameterDef!=null) {
        _attributes=_parameterDef.getAttributes();
      }
      return _attributes;
    } else {
      if ((instance instanceof TriggerInstance)) {
        TriggerDefinition _triggerDef = ((TriggerInstance)instance).getTriggerDef();
        EList<AttributeDefinition> _attributes_1 = null;
        if (_triggerDef!=null) {
          _attributes_1=_triggerDef.getAttributes();
        }
        return _attributes_1;
      }
    }
    return null;
  }
  
  public Iterable<AttributeDefinition> getAttributeDefs(final ComponentParameterBase param) {
    List<AttributeDefinition> _switchResult = null;
    boolean _matched = false;
    if (param instanceof InternalParameter) {
      _matched=true;
      _switchResult = ((InternalParameter)param).getAttributes();
    }
    if (!_matched) {
      if (param instanceof ExtendedParameter) {
        _matched=true;
        _switchResult = ((ExtendedParameter)param).getAttributes();
      }
    }
    if (!_matched) {
      if (param instanceof ParameterInstance) {
        _matched=true;
        final Function1<AttributeRefinement, AttributeDefinition> _function = (AttributeRefinement it) -> {
          return it.getAttribute();
        };
        _switchResult = ListExtensions.<AttributeRefinement, AttributeDefinition>map(((ParameterInstance)param).getAttributes(), _function);
      }
    }
    return _switchResult;
  }
}
