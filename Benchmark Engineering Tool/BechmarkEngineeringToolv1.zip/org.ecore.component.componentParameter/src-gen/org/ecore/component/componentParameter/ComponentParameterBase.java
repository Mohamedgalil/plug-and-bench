/**
 */
package org.ecore.component.componentParameter;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Base</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.componentParameter.ComponentParameterPackage#getComponentParameterBase()
 * @model abstract="true"
 * @generated
 */
public interface ComponentParameterBase extends EObject {
} // ComponentParameterBase
