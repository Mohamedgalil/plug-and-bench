/**
 */
package org.ecore.component.componentParameter;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Component Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.componentParameter.ComponentParameterPackage#getAbstractComponentParameter()
 * @model abstract="true"
 * @generated
 */
public interface AbstractComponentParameter extends EObject {
} // AbstractComponentParameter
