/**
 */
package org.ecore.component.componentParameter;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Parameter Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.componentParameter.ComponentParameterPackage#getAbstractParameterInstance()
 * @model abstract="true"
 * @generated
 */
public interface AbstractParameterInstance extends EObject {
} // AbstractParameterInstance
