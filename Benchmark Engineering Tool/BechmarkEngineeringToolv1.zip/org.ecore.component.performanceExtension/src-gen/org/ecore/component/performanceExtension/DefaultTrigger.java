/**
 */
package org.ecore.component.performanceExtension;

import org.ecore.component.componentDefinition.ActivityExtension;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Default Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.performanceExtension.PerformanceExtensionPackage#getDefaultTrigger()
 * @model abstract="true"
 * @generated
 */
public interface DefaultTrigger extends ActivityExtension {
} // DefaultTrigger
