/**
 */
package org.ecore.base.stateMachine;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.base.stateMachine.StateMachinePackage#getState()
 * @model
 * @generated
 */
public interface State extends AbstractStateElement {
} // State
