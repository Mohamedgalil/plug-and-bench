/**
 */
package org.ecore.base.stateMachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Machine Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.base.stateMachine.StateMachinePackage#getAbstractMachineElement()
 * @model abstract="true"
 * @generated
 */
public interface AbstractMachineElement extends EObject {
} // AbstractMachineElement
