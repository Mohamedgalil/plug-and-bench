/**
 */
package org.ecore.component.seronetExtension.impl;

import org.eclipse.emf.ecore.EClass;
import org.ecore.component.componentDefinition.impl.NamedComponentElementImpl;
import org.ecore.component.seronetExtension.PlainOpcUaPort;
import org.ecore.component.seronetExtension.SeronetExtensionPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Plain Opc Ua Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class PlainOpcUaPortImpl extends NamedComponentElementImpl implements PlainOpcUaPort {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlainOpcUaPortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SeronetExtensionPackage.Literals.PLAIN_OPC_UA_PORT;
	}

} //PlainOpcUaPortImpl
