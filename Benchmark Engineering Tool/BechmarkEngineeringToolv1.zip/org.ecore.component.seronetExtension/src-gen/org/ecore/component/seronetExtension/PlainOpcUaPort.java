/**
 */
package org.ecore.component.seronetExtension;

import org.ecore.component.componentDefinition.NamedComponentElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Plain Opc Ua Port</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.seronetExtension.SeronetExtensionPackage#getPlainOpcUaPort()
 * @model abstract="true"
 * @generated
 */
public interface PlainOpcUaPort extends NamedComponentElement {

} // PlainOpcUaPort
