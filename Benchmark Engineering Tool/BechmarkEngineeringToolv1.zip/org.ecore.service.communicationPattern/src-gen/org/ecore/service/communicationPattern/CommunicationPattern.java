/**
 */
package org.ecore.service.communicationPattern;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Communication Pattern</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.service.communicationPattern.CommunicationPatternPackage#getCommunicationPattern()
 * @model abstract="true"
 * @generated
 */
public interface CommunicationPattern extends EObject {
} // CommunicationPattern
