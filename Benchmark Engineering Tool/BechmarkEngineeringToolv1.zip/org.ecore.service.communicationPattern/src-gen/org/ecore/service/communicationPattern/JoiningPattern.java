/**
 */
package org.ecore.service.communicationPattern;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Joining Pattern</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.service.communicationPattern.CommunicationPatternPackage#getJoiningPattern()
 * @model abstract="true"
 * @generated
 */
public interface JoiningPattern extends OneWayCommunicationPattern {
} // JoiningPattern
