/**
 */
package org.ecore.component.componentDocumentation;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Neutral Mode Docu</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.componentDocumentation.ComponentDocumentationPackage#getNeutralModeDocu()
 * @model
 * @generated
 */
public interface NeutralModeDocu extends AbstractModeDocu {
} // NeutralModeDocu
