/**
 */
package org.ecore.component.componentDocumentation.impl;

import org.eclipse.emf.ecore.EClass;

import org.ecore.component.componentDocumentation.AbstractModeDocu;
import org.ecore.component.componentDocumentation.ComponentDocumentationPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Mode Docu</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class AbstractModeDocuImpl extends AbstractComponentDocuElementImpl implements AbstractModeDocu {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractModeDocuImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ComponentDocumentationPackage.Literals.ABSTRACT_MODE_DOCU;
	}

} //AbstractModeDocuImpl
