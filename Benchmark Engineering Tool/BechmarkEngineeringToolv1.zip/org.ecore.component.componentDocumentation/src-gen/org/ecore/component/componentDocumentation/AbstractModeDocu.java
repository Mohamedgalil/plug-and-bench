/**
 */
package org.ecore.component.componentDocumentation;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Mode Docu</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.componentDocumentation.ComponentDocumentationPackage#getAbstractModeDocu()
 * @model abstract="true"
 * @generated
 */
public interface AbstractModeDocu extends AbstractComponentDocuElement {
} // AbstractModeDocu
