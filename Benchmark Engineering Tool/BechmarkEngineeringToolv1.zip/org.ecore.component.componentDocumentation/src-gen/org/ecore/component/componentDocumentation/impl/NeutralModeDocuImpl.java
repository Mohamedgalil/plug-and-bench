/**
 */
package org.ecore.component.componentDocumentation.impl;

import org.eclipse.emf.ecore.EClass;

import org.ecore.component.componentDocumentation.ComponentDocumentationPackage;
import org.ecore.component.componentDocumentation.NeutralModeDocu;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Neutral Mode Docu</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NeutralModeDocuImpl extends AbstractModeDocuImpl implements NeutralModeDocu {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NeutralModeDocuImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ComponentDocumentationPackage.Literals.NEUTRAL_MODE_DOCU;
	}

} //NeutralModeDocuImpl
