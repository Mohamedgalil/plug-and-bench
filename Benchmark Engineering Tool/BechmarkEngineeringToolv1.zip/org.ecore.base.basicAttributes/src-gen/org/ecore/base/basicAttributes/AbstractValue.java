/**
 */
package org.ecore.base.basicAttributes;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.base.basicAttributes.BasicAttributesPackage#getAbstractValue()
 * @model abstract="true"
 * @generated
 */
public interface AbstractValue extends EObject {
} // AbstractValue
