/**
 */
package org.ecore.base.basicAttributes;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Single Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.base.basicAttributes.BasicAttributesPackage#getSingleValue()
 * @model
 * @generated
 */
public interface SingleValue extends AbstractValue {
} // SingleValue
