/**
 */
package benchmark_experiment;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import standardized_problem.Standardized_problemPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see benchmark_experiment.Benchmark_experimentFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/OCL/Import BasicAttributes='../../org.ecore.base.basicAttributes/model/basicAttributes.ecore#/' CommunicationObject_0='../../org.ecore.service.communicationObject/model/communicationObject.ecore#/' ComponentDefinition_0='../../org.ecore.component.componentDefinition/model/componentDefinition.ecore#/' ServiceDefinition='../../org.ecore.service.serviceDefinition/model/serviceDefinition.ecore#/' ecore='http://www.eclipse.org/emf/2002/Ecore'"
 * @generated
 */
public interface Benchmark_experimentPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "benchmark_experiment";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.ipa.frauhofer.de/benchmark_experiment";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "benchmark_experiment";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Benchmark_experimentPackage eINSTANCE = benchmark_experiment.impl.Benchmark_experimentPackageImpl.init();

	/**
	 * The meta object id for the '{@link benchmark_experiment.impl.ScenarioImpl <em>Scenario</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see benchmark_experiment.impl.ScenarioImpl
	 * @see benchmark_experiment.impl.Benchmark_experimentPackageImpl#getScenario()
	 * @generated
	 */
	int SCENARIO = 0;

	/**
	 * The feature id for the '<em><b>Test Data</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO__TEST_DATA = Standardized_problemPackage.ISCORE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ground Truth Data</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO__GROUND_TRUTH_DATA = Standardized_problemPackage.ISCORE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Recieved Data</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO__RECIEVED_DATA = Standardized_problemPackage.ISCORE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Perfvalue</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO__PERFVALUE = Standardized_problemPackage.ISCORE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Tuple</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO__TUPLE = Standardized_problemPackage.ISCORE_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Scenario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_FEATURE_COUNT = Standardized_problemPackage.ISCORE_FEATURE_COUNT + 5;

	/**
	 * The operation id for the '<em>Calc Score</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO___CALC_SCORE__ISCOREELEMENT = Standardized_problemPackage.ISCORE___CALC_SCORE__ISCOREELEMENT;

	/**
	 * The number of operations of the '<em>Scenario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_OPERATION_COUNT = Standardized_problemPackage.ISCORE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link benchmark_experiment.impl.BenchmarkExperimentImpl <em>Benchmark Experiment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see benchmark_experiment.impl.BenchmarkExperimentImpl
	 * @see benchmark_experiment.impl.Benchmark_experimentPackageImpl#getBenchmarkExperiment()
	 * @generated
	 */
	int BENCHMARK_EXPERIMENT = 1;

	/**
	 * The feature id for the '<em><b>Scenario</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_EXPERIMENT__SCENARIO = 0;

	/**
	 * The feature id for the '<em><b>Standardized Problem</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM = 1;

	/**
	 * The number of structural features of the '<em>Benchmark Experiment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_EXPERIMENT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Benchmark Experiment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_EXPERIMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link benchmark_experiment.impl.PerfValueImpl <em>Perf Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see benchmark_experiment.impl.PerfValueImpl
	 * @see benchmark_experiment.impl.Benchmark_experimentPackageImpl#getPerfValue()
	 * @generated
	 */
	int PERF_VALUE = 2;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERF_VALUE__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Weighted Perf Measure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERF_VALUE__WEIGHTED_PERF_MEASURE = 1;

	/**
	 * The number of structural features of the '<em>Perf Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERF_VALUE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Perf Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERF_VALUE_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link benchmark_experiment.Scenario <em>Scenario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Scenario</em>'.
	 * @see benchmark_experiment.Scenario
	 * @generated
	 */
	EClass getScenario();

	/**
	 * Returns the meta object for the reference list '{@link benchmark_experiment.Scenario#getTestData <em>Test Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Test Data</em>'.
	 * @see benchmark_experiment.Scenario#getTestData()
	 * @see #getScenario()
	 * @generated
	 */
	EReference getScenario_TestData();

	/**
	 * Returns the meta object for the reference list '{@link benchmark_experiment.Scenario#getGroundTruthData <em>Ground Truth Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ground Truth Data</em>'.
	 * @see benchmark_experiment.Scenario#getGroundTruthData()
	 * @see #getScenario()
	 * @generated
	 */
	EReference getScenario_GroundTruthData();

	/**
	 * Returns the meta object for the reference list '{@link benchmark_experiment.Scenario#getRecievedData <em>Recieved Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Recieved Data</em>'.
	 * @see benchmark_experiment.Scenario#getRecievedData()
	 * @see #getScenario()
	 * @generated
	 */
	EReference getScenario_RecievedData();

	/**
	 * Returns the meta object for the containment reference list '{@link benchmark_experiment.Scenario#getPerfvalue <em>Perfvalue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Perfvalue</em>'.
	 * @see benchmark_experiment.Scenario#getPerfvalue()
	 * @see #getScenario()
	 * @generated
	 */
	EReference getScenario_Perfvalue();

	/**
	 * Returns the meta object for the reference '{@link benchmark_experiment.Scenario#getTuple <em>Tuple</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Tuple</em>'.
	 * @see benchmark_experiment.Scenario#getTuple()
	 * @see #getScenario()
	 * @generated
	 */
	EReference getScenario_Tuple();

	/**
	 * Returns the meta object for class '{@link benchmark_experiment.BenchmarkExperiment <em>Benchmark Experiment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Benchmark Experiment</em>'.
	 * @see benchmark_experiment.BenchmarkExperiment
	 * @generated
	 */
	EClass getBenchmarkExperiment();

	/**
	 * Returns the meta object for the containment reference list '{@link benchmark_experiment.BenchmarkExperiment#getScenario <em>Scenario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Scenario</em>'.
	 * @see benchmark_experiment.BenchmarkExperiment#getScenario()
	 * @see #getBenchmarkExperiment()
	 * @generated
	 */
	EReference getBenchmarkExperiment_Scenario();

	/**
	 * Returns the meta object for the reference '{@link benchmark_experiment.BenchmarkExperiment#getStandardizedProblem <em>Standardized Problem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Standardized Problem</em>'.
	 * @see benchmark_experiment.BenchmarkExperiment#getStandardizedProblem()
	 * @see #getBenchmarkExperiment()
	 * @generated
	 */
	EReference getBenchmarkExperiment_StandardizedProblem();

	/**
	 * Returns the meta object for class '{@link benchmark_experiment.PerfValue <em>Perf Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Perf Value</em>'.
	 * @see benchmark_experiment.PerfValue
	 * @generated
	 */
	EClass getPerfValue();

	/**
	 * Returns the meta object for the attribute '{@link benchmark_experiment.PerfValue#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see benchmark_experiment.PerfValue#getValue()
	 * @see #getPerfValue()
	 * @generated
	 */
	EAttribute getPerfValue_Value();

	/**
	 * Returns the meta object for the reference '{@link benchmark_experiment.PerfValue#getWeightedPerfMeasure <em>Weighted Perf Measure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Weighted Perf Measure</em>'.
	 * @see benchmark_experiment.PerfValue#getWeightedPerfMeasure()
	 * @see #getPerfValue()
	 * @generated
	 */
	EReference getPerfValue_WeightedPerfMeasure();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Benchmark_experimentFactory getBenchmark_experimentFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link benchmark_experiment.impl.ScenarioImpl <em>Scenario</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see benchmark_experiment.impl.ScenarioImpl
		 * @see benchmark_experiment.impl.Benchmark_experimentPackageImpl#getScenario()
		 * @generated
		 */
		EClass SCENARIO = eINSTANCE.getScenario();

		/**
		 * The meta object literal for the '<em><b>Test Data</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO__TEST_DATA = eINSTANCE.getScenario_TestData();

		/**
		 * The meta object literal for the '<em><b>Ground Truth Data</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO__GROUND_TRUTH_DATA = eINSTANCE.getScenario_GroundTruthData();

		/**
		 * The meta object literal for the '<em><b>Recieved Data</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO__RECIEVED_DATA = eINSTANCE.getScenario_RecievedData();

		/**
		 * The meta object literal for the '<em><b>Perfvalue</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO__PERFVALUE = eINSTANCE.getScenario_Perfvalue();

		/**
		 * The meta object literal for the '<em><b>Tuple</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO__TUPLE = eINSTANCE.getScenario_Tuple();

		/**
		 * The meta object literal for the '{@link benchmark_experiment.impl.BenchmarkExperimentImpl <em>Benchmark Experiment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see benchmark_experiment.impl.BenchmarkExperimentImpl
		 * @see benchmark_experiment.impl.Benchmark_experimentPackageImpl#getBenchmarkExperiment()
		 * @generated
		 */
		EClass BENCHMARK_EXPERIMENT = eINSTANCE.getBenchmarkExperiment();

		/**
		 * The meta object literal for the '<em><b>Scenario</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BENCHMARK_EXPERIMENT__SCENARIO = eINSTANCE.getBenchmarkExperiment_Scenario();

		/**
		 * The meta object literal for the '<em><b>Standardized Problem</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM = eINSTANCE.getBenchmarkExperiment_StandardizedProblem();

		/**
		 * The meta object literal for the '{@link benchmark_experiment.impl.PerfValueImpl <em>Perf Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see benchmark_experiment.impl.PerfValueImpl
		 * @see benchmark_experiment.impl.Benchmark_experimentPackageImpl#getPerfValue()
		 * @generated
		 */
		EClass PERF_VALUE = eINSTANCE.getPerfValue();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERF_VALUE__VALUE = eINSTANCE.getPerfValue_Value();

		/**
		 * The meta object literal for the '<em><b>Weighted Perf Measure</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERF_VALUE__WEIGHTED_PERF_MEASURE = eINSTANCE.getPerfValue_WeightedPerfMeasure();

	}

} //Benchmark_experimentPackage
