/**
 */
package benchmark_experiment;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see benchmark_experiment.Benchmark_experimentPackage
 * @generated
 */
public interface Benchmark_experimentFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Benchmark_experimentFactory eINSTANCE = benchmark_experiment.impl.Benchmark_experimentFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Scenario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scenario</em>'.
	 * @generated
	 */
	Scenario createScenario();

	/**
	 * Returns a new object of class '<em>Benchmark Experiment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Benchmark Experiment</em>'.
	 * @generated
	 */
	BenchmarkExperiment createBenchmarkExperiment();

	/**
	 * Returns a new object of class '<em>Perf Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Perf Value</em>'.
	 * @generated
	 */
	PerfValue createPerfValue();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	Benchmark_experimentPackage getBenchmark_experimentPackage();

} //Benchmark_experimentFactory
