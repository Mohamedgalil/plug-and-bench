/**
 */
package benchmark_experiment;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

import standardized_problem.StandardizedProblem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Benchmark Experiment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link benchmark_experiment.BenchmarkExperiment#getScenario <em>Scenario</em>}</li>
 *   <li>{@link benchmark_experiment.BenchmarkExperiment#getStandardizedProblem <em>Standardized Problem</em>}</li>
 * </ul>
 *
 * @see benchmark_experiment.Benchmark_experimentPackage#getBenchmarkExperiment()
 * @model
 * @generated
 */
public interface BenchmarkExperiment extends EObject {
	/**
	 * Returns the value of the '<em><b>Scenario</b></em>' containment reference list.
	 * The list contents are of type {@link benchmark_experiment.Scenario}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scenario</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scenario</em>' containment reference list.
	 * @see benchmark_experiment.Benchmark_experimentPackage#getBenchmarkExperiment_Scenario()
	 * @model containment="true"
	 * @generated
	 */
	EList<Scenario> getScenario();

	/**
	 * Returns the value of the '<em><b>Standardized Problem</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Standardized Problem</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Standardized Problem</em>' reference.
	 * @see #setStandardizedProblem(StandardizedProblem)
	 * @see benchmark_experiment.Benchmark_experimentPackage#getBenchmarkExperiment_StandardizedProblem()
	 * @model
	 * @generated
	 */
	StandardizedProblem getStandardizedProblem();

	/**
	 * Sets the value of the '{@link benchmark_experiment.BenchmarkExperiment#getStandardizedProblem <em>Standardized Problem</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Standardized Problem</em>' reference.
	 * @see #getStandardizedProblem()
	 * @generated
	 */
	void setStandardizedProblem(StandardizedProblem value);

} // BenchmarkExperiment
