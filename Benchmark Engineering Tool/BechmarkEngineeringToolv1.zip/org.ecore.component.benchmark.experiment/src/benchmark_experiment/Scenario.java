/**
 */
package benchmark_experiment;

import org.eclipse.emf.common.util.EList;

import org.ecore.service.communicationObject.CommunicationObject;

import standardized_problem.IScore;
import standardized_problem.Tuple;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scenario</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * For one scenario to execute completely, it may need to send multiple testData , and recieve multiple recievedData, and then compare recievedData with GroundTruthData. The relevant output port and CommunicationObject can be know from:
 * * TestData: BenchmarkLifeCycle>StandardizedProblem>ServiceDefinition>...>CommObject
 * * RecievedData:
 * * OutputData:
 * 
 * The scenario will be created by the dynamic instance of the Benchmark component, and will point to a tuple.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link benchmark_experiment.Scenario#getTestData <em>Test Data</em>}</li>
 *   <li>{@link benchmark_experiment.Scenario#getGroundTruthData <em>Ground Truth Data</em>}</li>
 *   <li>{@link benchmark_experiment.Scenario#getRecievedData <em>Recieved Data</em>}</li>
 *   <li>{@link benchmark_experiment.Scenario#getPerfvalue <em>Perfvalue</em>}</li>
 *   <li>{@link benchmark_experiment.Scenario#getTuple <em>Tuple</em>}</li>
 * </ul>
 *
 * @see benchmark_experiment.Benchmark_experimentPackage#getScenario()
 * @model
 * @generated
 */
public interface Scenario extends IScore {
	/**
	 * Returns the value of the '<em><b>Test Data</b></em>' reference list.
	 * The list contents are of type {@link org.ecore.service.communicationObject.CommunicationObject}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The object which holds the Test data + Ground truth data.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Test Data</em>' reference list.
	 * @see benchmark_experiment.Benchmark_experimentPackage#getScenario_TestData()
	 * @model
	 * @generated
	 */
	EList<CommunicationObject> getTestData();

	/**
	 * Returns the value of the '<em><b>Ground Truth Data</b></em>' reference list.
	 * The list contents are of type {@link org.ecore.service.communicationObject.CommunicationObject}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The object which holds the Test data + Ground truth data.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Ground Truth Data</em>' reference list.
	 * @see benchmark_experiment.Benchmark_experimentPackage#getScenario_GroundTruthData()
	 * @model
	 * @generated
	 */
	EList<CommunicationObject> getGroundTruthData();

	/**
	 * Returns the value of the '<em><b>Recieved Data</b></em>' reference list.
	 * The list contents are of type {@link org.ecore.service.communicationObject.CommunicationObject}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Received outputData after executing the Query. The outputData can is a list --> can recieve multiple outputs per scenario
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Recieved Data</em>' reference list.
	 * @see benchmark_experiment.Benchmark_experimentPackage#getScenario_RecievedData()
	 * @model
	 * @generated
	 */
	EList<CommunicationObject> getRecievedData();

	/**
	 * Returns the value of the '<em><b>Perfvalue</b></em>' containment reference list.
	 * The list contents are of type {@link benchmark_experiment.PerfValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Each scenario has a performance value which reflects the result.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Perfvalue</em>' containment reference list.
	 * @see benchmark_experiment.Benchmark_experimentPackage#getScenario_Perfvalue()
	 * @model containment="true"
	 * @generated
	 */
	EList<PerfValue> getPerfvalue();

	/**
	 * Returns the value of the '<em><b>Tuple</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The scenario belongs to a tuple. The scenario can be a result of sending a tuple-query and recieving the result in the form of scenario with:
	 * 1. testData
	 * 2. GroundTruthData
	 * In case of Type-3 benchmarking: GroundTruthData can be received from external components
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Tuple</em>' reference.
	 * @see #setTuple(Tuple)
	 * @see benchmark_experiment.Benchmark_experimentPackage#getScenario_Tuple()
	 * @model required="true"
	 * @generated
	 */
	Tuple getTuple();

	/**
	 * Sets the value of the '{@link benchmark_experiment.Scenario#getTuple <em>Tuple</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tuple</em>' reference.
	 * @see #getTuple()
	 * @generated
	 */
	void setTuple(Tuple value);

} // Scenario
