/**
 */
package benchmark_experiment.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>Benchmark_experiment</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class Benchmark_experimentAllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new Benchmark_experimentAllTests("Benchmark_experiment Tests");
		suite.addTest(Benchmark_experimentTests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Benchmark_experimentAllTests(String name) {
		super(name);
	}

} //Benchmark_experimentAllTests
