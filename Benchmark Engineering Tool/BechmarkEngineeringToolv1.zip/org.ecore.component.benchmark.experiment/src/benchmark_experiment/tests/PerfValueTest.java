/**
 */
package benchmark_experiment.tests;

import benchmark_experiment.Benchmark_experimentFactory;
import benchmark_experiment.PerfValue;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Perf Value</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class PerfValueTest extends TestCase {

	/**
	 * The fixture for this Perf Value test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PerfValue fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(PerfValueTest.class);
	}

	/**
	 * Constructs a new Perf Value test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerfValueTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Perf Value test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(PerfValue fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Perf Value test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PerfValue getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Benchmark_experimentFactory.eINSTANCE.createPerfValue());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //PerfValueTest
