/**
 */
package benchmark_experiment.impl;

import benchmark_experiment.Benchmark_experimentPackage;
import benchmark_experiment.PerfValue;

import java.math.BigDecimal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import standardized_problem.WeightedPerfMeasure;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Perf Value</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link benchmark_experiment.impl.PerfValueImpl#getValue <em>Value</em>}</li>
 *   <li>{@link benchmark_experiment.impl.PerfValueImpl#getWeightedPerfMeasure <em>Weighted Perf Measure</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PerfValueImpl extends MinimalEObjectImpl.Container implements PerfValue {
	/**
	 * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected static final BigDecimal VALUE_EDEFAULT = new BigDecimal("0.0");

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected BigDecimal value = VALUE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getWeightedPerfMeasure() <em>Weighted Perf Measure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeightedPerfMeasure()
	 * @generated
	 * @ordered
	 */
	protected WeightedPerfMeasure weightedPerfMeasure;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PerfValueImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Benchmark_experimentPackage.Literals.PERF_VALUE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(BigDecimal newValue) {
		BigDecimal oldValue = value;
		value = newValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Benchmark_experimentPackage.PERF_VALUE__VALUE, oldValue, value));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WeightedPerfMeasure getWeightedPerfMeasure() {
		if (weightedPerfMeasure != null && weightedPerfMeasure.eIsProxy()) {
			InternalEObject oldWeightedPerfMeasure = (InternalEObject)weightedPerfMeasure;
			weightedPerfMeasure = (WeightedPerfMeasure)eResolveProxy(oldWeightedPerfMeasure);
			if (weightedPerfMeasure != oldWeightedPerfMeasure) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Benchmark_experimentPackage.PERF_VALUE__WEIGHTED_PERF_MEASURE, oldWeightedPerfMeasure, weightedPerfMeasure));
			}
		}
		return weightedPerfMeasure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WeightedPerfMeasure basicGetWeightedPerfMeasure() {
		return weightedPerfMeasure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWeightedPerfMeasure(WeightedPerfMeasure newWeightedPerfMeasure) {
		WeightedPerfMeasure oldWeightedPerfMeasure = weightedPerfMeasure;
		weightedPerfMeasure = newWeightedPerfMeasure;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Benchmark_experimentPackage.PERF_VALUE__WEIGHTED_PERF_MEASURE, oldWeightedPerfMeasure, weightedPerfMeasure));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Benchmark_experimentPackage.PERF_VALUE__VALUE:
				return getValue();
			case Benchmark_experimentPackage.PERF_VALUE__WEIGHTED_PERF_MEASURE:
				if (resolve) return getWeightedPerfMeasure();
				return basicGetWeightedPerfMeasure();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Benchmark_experimentPackage.PERF_VALUE__VALUE:
				setValue((BigDecimal)newValue);
				return;
			case Benchmark_experimentPackage.PERF_VALUE__WEIGHTED_PERF_MEASURE:
				setWeightedPerfMeasure((WeightedPerfMeasure)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Benchmark_experimentPackage.PERF_VALUE__VALUE:
				setValue(VALUE_EDEFAULT);
				return;
			case Benchmark_experimentPackage.PERF_VALUE__WEIGHTED_PERF_MEASURE:
				setWeightedPerfMeasure((WeightedPerfMeasure)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Benchmark_experimentPackage.PERF_VALUE__VALUE:
				return VALUE_EDEFAULT == null ? value != null : !VALUE_EDEFAULT.equals(value);
			case Benchmark_experimentPackage.PERF_VALUE__WEIGHTED_PERF_MEASURE:
				return weightedPerfMeasure != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (value: ");
		result.append(value);
		result.append(')');
		return result.toString();
	}

} //PerfValueImpl
