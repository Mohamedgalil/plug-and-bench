/**
 */
package benchmark_experiment.impl;

import benchmark_experiment.Benchmark_experimentPackage;
import benchmark_experiment.PerfValue;
import benchmark_experiment.Scenario;

import java.lang.reflect.InvocationTargetException;

import java.math.BigDecimal;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.ecore.service.communicationObject.CommunicationObject;

import standardized_problem.IScoreElement;
import standardized_problem.Tuple;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Scenario</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link benchmark_experiment.impl.ScenarioImpl#getTestData <em>Test Data</em>}</li>
 *   <li>{@link benchmark_experiment.impl.ScenarioImpl#getGroundTruthData <em>Ground Truth Data</em>}</li>
 *   <li>{@link benchmark_experiment.impl.ScenarioImpl#getRecievedData <em>Recieved Data</em>}</li>
 *   <li>{@link benchmark_experiment.impl.ScenarioImpl#getPerfvalue <em>Perfvalue</em>}</li>
 *   <li>{@link benchmark_experiment.impl.ScenarioImpl#getTuple <em>Tuple</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ScenarioImpl extends MinimalEObjectImpl.Container implements Scenario {
	/**
	 * The cached value of the '{@link #getTestData() <em>Test Data</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestData()
	 * @generated
	 * @ordered
	 */
	protected EList<CommunicationObject> testData;

	/**
	 * The cached value of the '{@link #getGroundTruthData() <em>Ground Truth Data</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGroundTruthData()
	 * @generated
	 * @ordered
	 */
	protected EList<CommunicationObject> groundTruthData;

	/**
	 * The cached value of the '{@link #getRecievedData() <em>Recieved Data</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecievedData()
	 * @generated
	 * @ordered
	 */
	protected EList<CommunicationObject> recievedData;

	/**
	 * The cached value of the '{@link #getPerfvalue() <em>Perfvalue</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPerfvalue()
	 * @generated
	 * @ordered
	 */
	protected EList<PerfValue> perfvalue;

	/**
	 * The cached value of the '{@link #getTuple() <em>Tuple</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTuple()
	 * @generated
	 * @ordered
	 */
	protected Tuple tuple;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ScenarioImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Benchmark_experimentPackage.Literals.SCENARIO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CommunicationObject> getTestData() {
		if (testData == null) {
			testData = new EObjectResolvingEList<CommunicationObject>(CommunicationObject.class, this, Benchmark_experimentPackage.SCENARIO__TEST_DATA);
		}
		return testData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CommunicationObject> getGroundTruthData() {
		if (groundTruthData == null) {
			groundTruthData = new EObjectResolvingEList<CommunicationObject>(CommunicationObject.class, this, Benchmark_experimentPackage.SCENARIO__GROUND_TRUTH_DATA);
		}
		return groundTruthData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CommunicationObject> getRecievedData() {
		if (recievedData == null) {
			recievedData = new EObjectResolvingEList<CommunicationObject>(CommunicationObject.class, this, Benchmark_experimentPackage.SCENARIO__RECIEVED_DATA);
		}
		return recievedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PerfValue> getPerfvalue() {
		if (perfvalue == null) {
			perfvalue = new EObjectContainmentEList<PerfValue>(PerfValue.class, this, Benchmark_experimentPackage.SCENARIO__PERFVALUE);
		}
		return perfvalue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tuple getTuple() {
		if (tuple != null && tuple.eIsProxy()) {
			InternalEObject oldTuple = (InternalEObject)tuple;
			tuple = (Tuple)eResolveProxy(oldTuple);
			if (tuple != oldTuple) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Benchmark_experimentPackage.SCENARIO__TUPLE, oldTuple, tuple));
			}
		}
		return tuple;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tuple basicGetTuple() {
		return tuple;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTuple(Tuple newTuple) {
		Tuple oldTuple = tuple;
		tuple = newTuple;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Benchmark_experimentPackage.SCENARIO__TUPLE, oldTuple, tuple));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal calcScore(IScoreElement scoreElement) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Benchmark_experimentPackage.SCENARIO__PERFVALUE:
				return ((InternalEList<?>)getPerfvalue()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Benchmark_experimentPackage.SCENARIO__TEST_DATA:
				return getTestData();
			case Benchmark_experimentPackage.SCENARIO__GROUND_TRUTH_DATA:
				return getGroundTruthData();
			case Benchmark_experimentPackage.SCENARIO__RECIEVED_DATA:
				return getRecievedData();
			case Benchmark_experimentPackage.SCENARIO__PERFVALUE:
				return getPerfvalue();
			case Benchmark_experimentPackage.SCENARIO__TUPLE:
				if (resolve) return getTuple();
				return basicGetTuple();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Benchmark_experimentPackage.SCENARIO__TEST_DATA:
				getTestData().clear();
				getTestData().addAll((Collection<? extends CommunicationObject>)newValue);
				return;
			case Benchmark_experimentPackage.SCENARIO__GROUND_TRUTH_DATA:
				getGroundTruthData().clear();
				getGroundTruthData().addAll((Collection<? extends CommunicationObject>)newValue);
				return;
			case Benchmark_experimentPackage.SCENARIO__RECIEVED_DATA:
				getRecievedData().clear();
				getRecievedData().addAll((Collection<? extends CommunicationObject>)newValue);
				return;
			case Benchmark_experimentPackage.SCENARIO__PERFVALUE:
				getPerfvalue().clear();
				getPerfvalue().addAll((Collection<? extends PerfValue>)newValue);
				return;
			case Benchmark_experimentPackage.SCENARIO__TUPLE:
				setTuple((Tuple)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Benchmark_experimentPackage.SCENARIO__TEST_DATA:
				getTestData().clear();
				return;
			case Benchmark_experimentPackage.SCENARIO__GROUND_TRUTH_DATA:
				getGroundTruthData().clear();
				return;
			case Benchmark_experimentPackage.SCENARIO__RECIEVED_DATA:
				getRecievedData().clear();
				return;
			case Benchmark_experimentPackage.SCENARIO__PERFVALUE:
				getPerfvalue().clear();
				return;
			case Benchmark_experimentPackage.SCENARIO__TUPLE:
				setTuple((Tuple)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Benchmark_experimentPackage.SCENARIO__TEST_DATA:
				return testData != null && !testData.isEmpty();
			case Benchmark_experimentPackage.SCENARIO__GROUND_TRUTH_DATA:
				return groundTruthData != null && !groundTruthData.isEmpty();
			case Benchmark_experimentPackage.SCENARIO__RECIEVED_DATA:
				return recievedData != null && !recievedData.isEmpty();
			case Benchmark_experimentPackage.SCENARIO__PERFVALUE:
				return perfvalue != null && !perfvalue.isEmpty();
			case Benchmark_experimentPackage.SCENARIO__TUPLE:
				return tuple != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Benchmark_experimentPackage.SCENARIO___CALC_SCORE__ISCOREELEMENT:
				return calcScore((IScoreElement)arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

} //ScenarioImpl
