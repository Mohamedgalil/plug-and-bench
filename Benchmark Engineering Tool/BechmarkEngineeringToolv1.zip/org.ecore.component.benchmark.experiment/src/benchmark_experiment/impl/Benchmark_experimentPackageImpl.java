/**
 */
package benchmark_experiment.impl;

import benchmark_experiment.BenchmarkExperiment;
import benchmark_experiment.Benchmark_experimentFactory;
import benchmark_experiment.Benchmark_experimentPackage;
import benchmark_experiment.PerfValue;
import benchmark_experiment.Scenario;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.ecore.base.basicAttributes.BasicAttributesPackage;

import org.ecore.base.stateMachine.StateMachinePackage;

import org.ecore.service.communicationObject.CommunicationObjectPackage;

import org.ecore.service.communicationPattern.CommunicationPatternPackage;

import org.ecore.service.componentMode.ComponentModePackage;

import org.ecore.service.coordinationPattern.CoordinationPatternPackage;

import org.ecore.service.parameterDefinition.ParameterDefinitionPackage;

import org.ecore.service.serviceDefinition.ServiceDefinitionPackage;

import standardized_problem.Standardized_problemPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Benchmark_experimentPackageImpl extends EPackageImpl implements Benchmark_experimentPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass scenarioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass benchmarkExperimentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass perfValueEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see benchmark_experiment.Benchmark_experimentPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Benchmark_experimentPackageImpl() {
		super(eNS_URI, Benchmark_experimentFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Benchmark_experimentPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Benchmark_experimentPackage init() {
		if (isInited) return (Benchmark_experimentPackage)EPackage.Registry.INSTANCE.getEPackage(Benchmark_experimentPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredBenchmark_experimentPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		Benchmark_experimentPackageImpl theBenchmark_experimentPackage = registeredBenchmark_experimentPackage instanceof Benchmark_experimentPackageImpl ? (Benchmark_experimentPackageImpl)registeredBenchmark_experimentPackage : new Benchmark_experimentPackageImpl();

		isInited = true;

		// Initialize simple dependencies
		BasicAttributesPackage.eINSTANCE.eClass();
		CommunicationObjectPackage.eINSTANCE.eClass();
		CommunicationPatternPackage.eINSTANCE.eClass();
		ComponentModePackage.eINSTANCE.eClass();
		CoordinationPatternPackage.eINSTANCE.eClass();
		ParameterDefinitionPackage.eINSTANCE.eClass();
		ServiceDefinitionPackage.eINSTANCE.eClass();
		Standardized_problemPackage.eINSTANCE.eClass();
		StateMachinePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theBenchmark_experimentPackage.createPackageContents();

		// Initialize created meta-data
		theBenchmark_experimentPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theBenchmark_experimentPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Benchmark_experimentPackage.eNS_URI, theBenchmark_experimentPackage);
		return theBenchmark_experimentPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getScenario() {
		return scenarioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenario_TestData() {
		return (EReference)scenarioEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenario_GroundTruthData() {
		return (EReference)scenarioEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenario_RecievedData() {
		return (EReference)scenarioEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenario_Perfvalue() {
		return (EReference)scenarioEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenario_Tuple() {
		return (EReference)scenarioEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBenchmarkExperiment() {
		return benchmarkExperimentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBenchmarkExperiment_Scenario() {
		return (EReference)benchmarkExperimentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBenchmarkExperiment_StandardizedProblem() {
		return (EReference)benchmarkExperimentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPerfValue() {
		return perfValueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPerfValue_Value() {
		return (EAttribute)perfValueEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPerfValue_WeightedPerfMeasure() {
		return (EReference)perfValueEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Benchmark_experimentFactory getBenchmark_experimentFactory() {
		return (Benchmark_experimentFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		scenarioEClass = createEClass(SCENARIO);
		createEReference(scenarioEClass, SCENARIO__TEST_DATA);
		createEReference(scenarioEClass, SCENARIO__GROUND_TRUTH_DATA);
		createEReference(scenarioEClass, SCENARIO__RECIEVED_DATA);
		createEReference(scenarioEClass, SCENARIO__PERFVALUE);
		createEReference(scenarioEClass, SCENARIO__TUPLE);

		benchmarkExperimentEClass = createEClass(BENCHMARK_EXPERIMENT);
		createEReference(benchmarkExperimentEClass, BENCHMARK_EXPERIMENT__SCENARIO);
		createEReference(benchmarkExperimentEClass, BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM);

		perfValueEClass = createEClass(PERF_VALUE);
		createEAttribute(perfValueEClass, PERF_VALUE__VALUE);
		createEReference(perfValueEClass, PERF_VALUE__WEIGHTED_PERF_MEASURE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		Standardized_problemPackage theStandardized_problemPackage = (Standardized_problemPackage)EPackage.Registry.INSTANCE.getEPackage(Standardized_problemPackage.eNS_URI);
		CommunicationObjectPackage theCommunicationObjectPackage = (CommunicationObjectPackage)EPackage.Registry.INSTANCE.getEPackage(CommunicationObjectPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		scenarioEClass.getESuperTypes().add(theStandardized_problemPackage.getIScore());

		// Initialize classes, features, and operations; add parameters
		initEClass(scenarioEClass, Scenario.class, "Scenario", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getScenario_TestData(), theCommunicationObjectPackage.getCommunicationObject(), null, "testData", null, 0, -1, Scenario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getScenario_GroundTruthData(), theCommunicationObjectPackage.getCommunicationObject(), null, "groundTruthData", null, 0, -1, Scenario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getScenario_RecievedData(), theCommunicationObjectPackage.getCommunicationObject(), null, "recievedData", null, 0, -1, Scenario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getScenario_Perfvalue(), this.getPerfValue(), null, "perfvalue", null, 0, -1, Scenario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getScenario_Tuple(), theStandardized_problemPackage.getTuple(), null, "tuple", null, 1, 1, Scenario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(benchmarkExperimentEClass, BenchmarkExperiment.class, "BenchmarkExperiment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBenchmarkExperiment_Scenario(), this.getScenario(), null, "scenario", null, 0, -1, BenchmarkExperiment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBenchmarkExperiment_StandardizedProblem(), theStandardized_problemPackage.getStandardizedProblem(), null, "standardizedProblem", null, 0, 1, BenchmarkExperiment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(perfValueEClass, PerfValue.class, "PerfValue", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPerfValue_Value(), ecorePackage.getEBigDecimal(), "value", "0.0", 0, 1, PerfValue.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPerfValue_WeightedPerfMeasure(), theStandardized_problemPackage.getWeightedPerfMeasure(), null, "weightedPerfMeasure", null, 1, 1, PerfValue.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/OCL/Import
		createImportAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Import</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createImportAnnotations() {
		String source = "http://www.eclipse.org/OCL/Import";
		addAnnotation
		  (this,
		   source,
		   new String[] {
			   "BasicAttributes", "../../org.ecore.base.basicAttributes/model/basicAttributes.ecore#/",
			   "CommunicationObject_0", "../../org.ecore.service.communicationObject/model/communicationObject.ecore#/",
			   "ComponentDefinition_0", "../../org.ecore.component.componentDefinition/model/componentDefinition.ecore#/",
			   "ServiceDefinition", "../../org.ecore.service.serviceDefinition/model/serviceDefinition.ecore#/",
			   "ecore", "http://www.eclipse.org/emf/2002/Ecore"
		   });
	}

} //Benchmark_experimentPackageImpl
