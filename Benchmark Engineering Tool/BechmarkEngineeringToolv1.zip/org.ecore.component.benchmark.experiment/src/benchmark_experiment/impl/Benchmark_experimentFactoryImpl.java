/**
 */
package benchmark_experiment.impl;

import benchmark_experiment.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Benchmark_experimentFactoryImpl extends EFactoryImpl implements Benchmark_experimentFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Benchmark_experimentFactory init() {
		try {
			Benchmark_experimentFactory theBenchmark_experimentFactory = (Benchmark_experimentFactory)EPackage.Registry.INSTANCE.getEFactory(Benchmark_experimentPackage.eNS_URI);
			if (theBenchmark_experimentFactory != null) {
				return theBenchmark_experimentFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Benchmark_experimentFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Benchmark_experimentFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case Benchmark_experimentPackage.SCENARIO: return createScenario();
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT: return createBenchmarkExperiment();
			case Benchmark_experimentPackage.PERF_VALUE: return createPerfValue();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Scenario createScenario() {
		ScenarioImpl scenario = new ScenarioImpl();
		return scenario;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BenchmarkExperiment createBenchmarkExperiment() {
		BenchmarkExperimentImpl benchmarkExperiment = new BenchmarkExperimentImpl();
		return benchmarkExperiment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerfValue createPerfValue() {
		PerfValueImpl perfValue = new PerfValueImpl();
		return perfValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Benchmark_experimentPackage getBenchmark_experimentPackage() {
		return (Benchmark_experimentPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Benchmark_experimentPackage getPackage() {
		return Benchmark_experimentPackage.eINSTANCE;
	}

} //Benchmark_experimentFactoryImpl
