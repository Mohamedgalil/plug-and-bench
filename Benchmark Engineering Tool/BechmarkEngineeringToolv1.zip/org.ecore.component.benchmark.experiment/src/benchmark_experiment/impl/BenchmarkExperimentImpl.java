/**
 */
package benchmark_experiment.impl;

import benchmark_experiment.BenchmarkExperiment;
import benchmark_experiment.Benchmark_experimentPackage;
import benchmark_experiment.Scenario;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import standardized_problem.StandardizedProblem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Benchmark Experiment</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link benchmark_experiment.impl.BenchmarkExperimentImpl#getScenario <em>Scenario</em>}</li>
 *   <li>{@link benchmark_experiment.impl.BenchmarkExperimentImpl#getStandardizedProblem <em>Standardized Problem</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BenchmarkExperimentImpl extends MinimalEObjectImpl.Container implements BenchmarkExperiment {
	/**
	 * The cached value of the '{@link #getScenario() <em>Scenario</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScenario()
	 * @generated
	 * @ordered
	 */
	protected EList<Scenario> scenario;

	/**
	 * The cached value of the '{@link #getStandardizedProblem() <em>Standardized Problem</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStandardizedProblem()
	 * @generated
	 * @ordered
	 */
	protected StandardizedProblem standardizedProblem;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BenchmarkExperimentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Benchmark_experimentPackage.Literals.BENCHMARK_EXPERIMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Scenario> getScenario() {
		if (scenario == null) {
			scenario = new EObjectContainmentEList<Scenario>(Scenario.class, this, Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__SCENARIO);
		}
		return scenario;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StandardizedProblem getStandardizedProblem() {
		if (standardizedProblem != null && standardizedProblem.eIsProxy()) {
			InternalEObject oldStandardizedProblem = (InternalEObject)standardizedProblem;
			standardizedProblem = (StandardizedProblem)eResolveProxy(oldStandardizedProblem);
			if (standardizedProblem != oldStandardizedProblem) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM, oldStandardizedProblem, standardizedProblem));
			}
		}
		return standardizedProblem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StandardizedProblem basicGetStandardizedProblem() {
		return standardizedProblem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStandardizedProblem(StandardizedProblem newStandardizedProblem) {
		StandardizedProblem oldStandardizedProblem = standardizedProblem;
		standardizedProblem = newStandardizedProblem;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM, oldStandardizedProblem, standardizedProblem));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__SCENARIO:
				return ((InternalEList<?>)getScenario()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__SCENARIO:
				return getScenario();
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM:
				if (resolve) return getStandardizedProblem();
				return basicGetStandardizedProblem();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__SCENARIO:
				getScenario().clear();
				getScenario().addAll((Collection<? extends Scenario>)newValue);
				return;
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM:
				setStandardizedProblem((StandardizedProblem)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__SCENARIO:
				getScenario().clear();
				return;
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM:
				setStandardizedProblem((StandardizedProblem)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__SCENARIO:
				return scenario != null && !scenario.isEmpty();
			case Benchmark_experimentPackage.BENCHMARK_EXPERIMENT__STANDARDIZED_PROBLEM:
				return standardizedProblem != null;
		}
		return super.eIsSet(featureID);
	}

} //BenchmarkExperimentImpl
