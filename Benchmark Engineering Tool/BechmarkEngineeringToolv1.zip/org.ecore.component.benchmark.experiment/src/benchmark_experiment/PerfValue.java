/**
 */
package benchmark_experiment;

import java.math.BigDecimal;

import org.eclipse.emf.ecore.EObject;

import standardized_problem.WeightedPerfMeasure;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Perf Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link benchmark_experiment.PerfValue#getValue <em>Value</em>}</li>
 *   <li>{@link benchmark_experiment.PerfValue#getWeightedPerfMeasure <em>Weighted Perf Measure</em>}</li>
 * </ul>
 *
 * @see benchmark_experiment.Benchmark_experimentPackage#getPerfValue()
 * @model
 * @generated
 */
public interface PerfValue extends EObject {
	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(BigDecimal)
	 * @see benchmark_experiment.Benchmark_experimentPackage#getPerfValue_Value()
	 * @model default="0.0"
	 * @generated
	 */
	BigDecimal getValue();

	/**
	 * Sets the value of the '{@link benchmark_experiment.PerfValue#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(BigDecimal value);

	/**
	 * Returns the value of the '<em><b>Weighted Perf Measure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Weighted Perf Measure</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weighted Perf Measure</em>' reference.
	 * @see #setWeightedPerfMeasure(WeightedPerfMeasure)
	 * @see benchmark_experiment.Benchmark_experimentPackage#getPerfValue_WeightedPerfMeasure()
	 * @model required="true"
	 * @generated
	 */
	WeightedPerfMeasure getWeightedPerfMeasure();

	/**
	 * Sets the value of the '{@link benchmark_experiment.PerfValue#getWeightedPerfMeasure <em>Weighted Perf Measure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Weighted Perf Measure</em>' reference.
	 * @see #getWeightedPerfMeasure()
	 * @generated
	 */
	void setWeightedPerfMeasure(WeightedPerfMeasure value);

} // PerfValue
