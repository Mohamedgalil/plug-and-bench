/**
 */
package org.ecore.component.componentDefinition;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Activity Extension</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.componentDefinition.ComponentDefinitionPackage#getActivityExtension()
 * @model abstract="true"
 * @generated
 */
public interface ActivityExtension extends EObject {
} // ActivityExtension
