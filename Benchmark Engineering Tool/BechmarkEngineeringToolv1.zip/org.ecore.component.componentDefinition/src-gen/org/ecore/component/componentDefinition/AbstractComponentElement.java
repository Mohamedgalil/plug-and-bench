/**
 */
package org.ecore.component.componentDefinition;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Component Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.componentDefinition.ComponentDefinitionPackage#getAbstractComponentElement()
 * @model abstract="true"
 * @generated
 */
public interface AbstractComponentElement extends EObject {

} // AbstractComponentElement
