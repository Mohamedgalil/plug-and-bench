/**
 */
package org.ecore.component.componentDefinition;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component Port Extension</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.ecore.component.componentDefinition.ComponentDefinitionPackage#getComponentPortExtension()
 * @model abstract="true"
 * @generated
 */
public interface ComponentPortExtension extends EObject {
} // ComponentPortExtension
