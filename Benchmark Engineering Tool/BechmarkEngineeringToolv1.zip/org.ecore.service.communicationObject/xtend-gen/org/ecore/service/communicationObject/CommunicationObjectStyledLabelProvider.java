package org.ecore.service.communicationObject;

import org.ecore.base.basicAttributes.AbstractAttributeType;
import org.ecore.base.basicAttributes.AbstractValue;
import org.ecore.base.basicAttributes.BasicAttributesStyledLabelProvider;
import org.ecore.service.communicationObject.CommElementReference;
import org.ecore.service.communicationObject.CommElementValue;

@SuppressWarnings("all")
public class CommunicationObjectStyledLabelProvider extends BasicAttributesStyledLabelProvider {
  @Override
  public String getValueString(final AbstractValue av) {
    String _xifexpression = null;
    if ((av instanceof CommElementValue)) {
      return ((CommElementValue)av).getValue().getName();
    } else {
      _xifexpression = super.getValueString(av);
    }
    return _xifexpression;
  }
  
  @Override
  public String getTypeName(final AbstractAttributeType attrType) {
    String _xifexpression = null;
    if ((attrType instanceof CommElementReference)) {
      return ((CommElementReference)attrType).getTypeName().getName();
    } else {
      _xifexpression = super.getTypeName(attrType);
    }
    return _xifexpression;
  }
}
