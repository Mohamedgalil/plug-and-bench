/**
 */
package standardized_problem;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see standardized_problem.Standardized_problemPackage
 * @generated
 */
public interface Standardized_problemFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Standardized_problemFactory eINSTANCE = standardized_problem.impl.Standardized_problemFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Standardized Problem</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Standardized Problem</em>'.
	 * @generated
	 */
	StandardizedProblem createStandardizedProblem();

	/**
	 * Returns a new object of class '<em>Scenario Def</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scenario Def</em>'.
	 * @generated
	 */
	ScenarioDef createScenarioDef();

	/**
	 * Returns a new object of class '<em>Performance Measure</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Performance Measure</em>'.
	 * @generated
	 */
	PerformanceMeasure createPerformanceMeasure();

	/**
	 * Returns a new object of class '<em>Environment Variable</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Environment Variable</em>'.
	 * @generated
	 */
	EnvironmentVariable createEnvironmentVariable();

	/**
	 * Returns a new object of class '<em>Tuple</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tuple</em>'.
	 * @generated
	 */
	Tuple createTuple();

	/**
	 * Returns a new object of class '<em>Weighted Perf Measure</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Weighted Perf Measure</em>'.
	 * @generated
	 */
	WeightedPerfMeasure createWeightedPerfMeasure();

	/**
	 * Returns a new object of class '<em>Env Var Val</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Env Var Val</em>'.
	 * @generated
	 */
	EnvVarVal createEnvVarVal();

	/**
	 * Returns a new object of class '<em>Benchmark Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Benchmark Constraint</em>'.
	 * @generated
	 */
	BenchmarkConstraint createBenchmarkConstraint();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	Standardized_problemPackage getStandardized_problemPackage();

} //Standardized_problemFactory
