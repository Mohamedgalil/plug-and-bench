/**
 */
package standardized_problem;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.ecore.base.basicAttributes.BasicAttributesPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see standardized_problem.Standardized_problemFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/OCL/Import BasicAttributes='../../org.ecore.base.basicAttributes/model/basicAttributes.ecore#/' CommunicationObject_0='../../org.ecore.service.communicationObject/model/communicationObject.ecore#/' ComponentDefinition_0='../../org.ecore.component.componentDefinition/model/componentDefinition.ecore#/' ServiceDefinition='../../org.ecore.service.serviceDefinition/model/serviceDefinition.ecore#/' ecore='http://www.eclipse.org/emf/2002/Ecore'"
 * @generated
 */
public interface Standardized_problemPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "standardized_problem";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.ipa.frauhofer.de/standardized_problem";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "standardized_problem";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Standardized_problemPackage eINSTANCE = standardized_problem.impl.Standardized_problemPackageImpl.init();

	/**
	 * The meta object id for the '{@link standardized_problem.impl.DescriptorObjectImpl <em>Descriptor Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.DescriptorObjectImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getDescriptorObject()
	 * @generated
	 */
	int DESCRIPTOR_OBJECT = 3;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESCRIPTOR_OBJECT__LABEL = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESCRIPTOR_OBJECT__DESCRIPTION = 1;

	/**
	 * The number of structural features of the '<em>Descriptor Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESCRIPTOR_OBJECT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Descriptor Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESCRIPTOR_OBJECT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.StandardizedProblemImpl <em>Standardized Problem</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.StandardizedProblemImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getStandardizedProblem()
	 * @generated
	 */
	int STANDARDIZED_PROBLEM = 0;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM__LABEL = DESCRIPTOR_OBJECT__LABEL;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM__DESCRIPTION = DESCRIPTOR_OBJECT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Score</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM__SCORE = DESCRIPTOR_OBJECT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Scenario Definitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS = DESCRIPTOR_OBJECT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Performance Criteria</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA = DESCRIPTOR_OBJECT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Comm Service Def</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM__COMM_SERVICE_DEF = DESCRIPTOR_OBJECT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Standardized Problem</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM_FEATURE_COUNT = DESCRIPTOR_OBJECT_FEATURE_COUNT + 4;

	/**
	 * The operation id for the '<em>Calc Score</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM___CALC_SCORE__ISCOREELEMENT = DESCRIPTOR_OBJECT_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Standardized Problem</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARDIZED_PROBLEM_OPERATION_COUNT = DESCRIPTOR_OBJECT_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.ScenarioDefImpl <em>Scenario Def</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.ScenarioDefImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getScenarioDef()
	 * @generated
	 */
	int SCENARIO_DEF = 1;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__LABEL = DESCRIPTOR_OBJECT__LABEL;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__DESCRIPTION = DESCRIPTOR_OBJECT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Score</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__SCORE = DESCRIPTOR_OBJECT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Dimensions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__DIMENSIONS = DESCRIPTOR_OBJECT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Comm Serv Def</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__COMM_SERV_DEF = DESCRIPTOR_OBJECT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Weight</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__WEIGHT = DESCRIPTOR_OBJECT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Attribute Definition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__ATTRIBUTE_DEFINITION = DESCRIPTOR_OBJECT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Tuple</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__TUPLE = DESCRIPTOR_OBJECT_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Performance Measures</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__PERFORMANCE_MEASURES = DESCRIPTOR_OBJECT_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Benchmarkconstraint</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF__BENCHMARKCONSTRAINT = DESCRIPTOR_OBJECT_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Scenario Def</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF_FEATURE_COUNT = DESCRIPTOR_OBJECT_FEATURE_COUNT + 8;

	/**
	 * The operation id for the '<em>Calc Score</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF___CALC_SCORE__ISCOREELEMENT = DESCRIPTOR_OBJECT_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Scenario Def</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCENARIO_DEF_OPERATION_COUNT = DESCRIPTOR_OBJECT_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.PerformanceMeasureImpl <em>Performance Measure</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.PerformanceMeasureImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getPerformanceMeasure()
	 * @generated
	 */
	int PERFORMANCE_MEASURE = 2;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMANCE_MEASURE__LABEL = DESCRIPTOR_OBJECT__LABEL;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMANCE_MEASURE__DESCRIPTION = DESCRIPTOR_OBJECT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMANCE_MEASURE__METRIC = DESCRIPTOR_OBJECT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Performance Measure</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMANCE_MEASURE_FEATURE_COUNT = DESCRIPTOR_OBJECT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Performance Measure</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMANCE_MEASURE_OPERATION_COUNT = DESCRIPTOR_OBJECT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.EnvironmentVariableImpl <em>Environment Variable</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.EnvironmentVariableImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getEnvironmentVariable()
	 * @generated
	 */
	int ENVIRONMENT_VARIABLE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_VARIABLE__NAME = BasicAttributesPackage.ATTRIBUTE_DEFINITION__NAME;

	/**
	 * The feature id for the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_VARIABLE__TYPE = BasicAttributesPackage.ATTRIBUTE_DEFINITION__TYPE;

	/**
	 * The feature id for the '<em><b>Defaultvalue</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_VARIABLE__DEFAULTVALUE = BasicAttributesPackage.ATTRIBUTE_DEFINITION__DEFAULTVALUE;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_VARIABLE__DESCRIPTION = BasicAttributesPackage.ATTRIBUTE_DEFINITION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Environment Variable</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_VARIABLE_FEATURE_COUNT = BasicAttributesPackage.ATTRIBUTE_DEFINITION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Environment Variable</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_VARIABLE_OPERATION_COUNT = BasicAttributesPackage.ATTRIBUTE_DEFINITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.IScoreElementImpl <em>IScore Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.IScoreElementImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getIScoreElement()
	 * @generated
	 */
	int ISCORE_ELEMENT = 5;

	/**
	 * The feature id for the '<em><b>Score</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISCORE_ELEMENT__SCORE = 0;

	/**
	 * The number of structural features of the '<em>IScore Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISCORE_ELEMENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>IScore Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISCORE_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link standardized_problem.IScore <em>IScore</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.IScore
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getIScore()
	 * @generated
	 */
	int ISCORE = 6;

	/**
	 * The number of structural features of the '<em>IScore</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISCORE_FEATURE_COUNT = 0;

	/**
	 * The operation id for the '<em>Calc Score</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISCORE___CALC_SCORE__ISCOREELEMENT = 0;

	/**
	 * The number of operations of the '<em>IScore</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISCORE_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.TupleImpl <em>Tuple</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.TupleImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getTuple()
	 * @generated
	 */
	int TUPLE = 7;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE__LABEL = DESCRIPTOR_OBJECT__LABEL;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE__DESCRIPTION = DESCRIPTOR_OBJECT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Scenario Def</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE__SCENARIO_DEF = DESCRIPTOR_OBJECT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Comm Service Def</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE__COMM_SERVICE_DEF = DESCRIPTOR_OBJECT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Weight</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE__WEIGHT = DESCRIPTOR_OBJECT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Comm Object</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE__COMM_OBJECT = DESCRIPTOR_OBJECT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Weightedperfmeasure</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE__WEIGHTEDPERFMEASURE = DESCRIPTOR_OBJECT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Env Var Val</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE__ENV_VAR_VAL = DESCRIPTOR_OBJECT_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Tuple</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE_FEATURE_COUNT = DESCRIPTOR_OBJECT_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Tuple</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TUPLE_OPERATION_COUNT = DESCRIPTOR_OBJECT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.WeightedPerfMeasureImpl <em>Weighted Perf Measure</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.WeightedPerfMeasureImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getWeightedPerfMeasure()
	 * @generated
	 */
	int WEIGHTED_PERF_MEASURE = 8;

	/**
	 * The feature id for the '<em><b>Weight</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEIGHTED_PERF_MEASURE__WEIGHT = 0;

	/**
	 * The feature id for the '<em><b>Perf Measure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEIGHTED_PERF_MEASURE__PERF_MEASURE = 1;

	/**
	 * The number of structural features of the '<em>Weighted Perf Measure</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEIGHTED_PERF_MEASURE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Weighted Perf Measure</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEIGHTED_PERF_MEASURE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.EnvVarValImpl <em>Env Var Val</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.EnvVarValImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getEnvVarVal()
	 * @generated
	 */
	int ENV_VAR_VAL = 9;

	/**
	 * The feature id for the '<em><b>Value</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENV_VAR_VAL__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Environment Variable</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENV_VAR_VAL__ENVIRONMENT_VARIABLE = 1;

	/**
	 * The number of structural features of the '<em>Env Var Val</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENV_VAR_VAL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Env Var Val</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENV_VAR_VAL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link standardized_problem.impl.BenchmarkConstraintImpl <em>Benchmark Constraint</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.impl.BenchmarkConstraintImpl
	 * @see standardized_problem.impl.Standardized_problemPackageImpl#getBenchmarkConstraint()
	 * @generated
	 */
	int BENCHMARK_CONSTRAINT = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_CONSTRAINT__NAME = BasicAttributesPackage.ATTRIBUTE_DEFINITION__NAME;

	/**
	 * The feature id for the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_CONSTRAINT__TYPE = BasicAttributesPackage.ATTRIBUTE_DEFINITION__TYPE;

	/**
	 * The feature id for the '<em><b>Defaultvalue</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_CONSTRAINT__DEFAULTVALUE = BasicAttributesPackage.ATTRIBUTE_DEFINITION__DEFAULTVALUE;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_CONSTRAINT__DESCRIPTION = BasicAttributesPackage.ATTRIBUTE_DEFINITION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Benchmark Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_CONSTRAINT_FEATURE_COUNT = BasicAttributesPackage.ATTRIBUTE_DEFINITION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Benchmark Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BENCHMARK_CONSTRAINT_OPERATION_COUNT = BasicAttributesPackage.ATTRIBUTE_DEFINITION_OPERATION_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link standardized_problem.StandardizedProblem <em>Standardized Problem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Standardized Problem</em>'.
	 * @see standardized_problem.StandardizedProblem
	 * @generated
	 */
	EClass getStandardizedProblem();

	/**
	 * Returns the meta object for the containment reference list '{@link standardized_problem.StandardizedProblem#getScenarioDefinitions <em>Scenario Definitions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Scenario Definitions</em>'.
	 * @see standardized_problem.StandardizedProblem#getScenarioDefinitions()
	 * @see #getStandardizedProblem()
	 * @generated
	 */
	EReference getStandardizedProblem_ScenarioDefinitions();

	/**
	 * Returns the meta object for the containment reference list '{@link standardized_problem.StandardizedProblem#getPerformanceCriteria <em>Performance Criteria</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Performance Criteria</em>'.
	 * @see standardized_problem.StandardizedProblem#getPerformanceCriteria()
	 * @see #getStandardizedProblem()
	 * @generated
	 */
	EReference getStandardizedProblem_PerformanceCriteria();

	/**
	 * Returns the meta object for the reference list '{@link standardized_problem.StandardizedProblem#getCommServiceDef <em>Comm Service Def</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Comm Service Def</em>'.
	 * @see standardized_problem.StandardizedProblem#getCommServiceDef()
	 * @see #getStandardizedProblem()
	 * @generated
	 */
	EReference getStandardizedProblem_CommServiceDef();

	/**
	 * Returns the meta object for class '{@link standardized_problem.ScenarioDef <em>Scenario Def</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Scenario Def</em>'.
	 * @see standardized_problem.ScenarioDef
	 * @generated
	 */
	EClass getScenarioDef();

	/**
	 * Returns the meta object for the containment reference list '{@link standardized_problem.ScenarioDef#getDimensions <em>Dimensions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dimensions</em>'.
	 * @see standardized_problem.ScenarioDef#getDimensions()
	 * @see #getScenarioDef()
	 * @generated
	 */
	EReference getScenarioDef_Dimensions();

	/**
	 * Returns the meta object for the reference list '{@link standardized_problem.ScenarioDef#getCommServDef <em>Comm Serv Def</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Comm Serv Def</em>'.
	 * @see standardized_problem.ScenarioDef#getCommServDef()
	 * @see #getScenarioDef()
	 * @generated
	 */
	EReference getScenarioDef_CommServDef();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.ScenarioDef#getWeight <em>Weight</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Weight</em>'.
	 * @see standardized_problem.ScenarioDef#getWeight()
	 * @see #getScenarioDef()
	 * @generated
	 */
	EAttribute getScenarioDef_Weight();

	/**
	 * Returns the meta object for the reference list '{@link standardized_problem.ScenarioDef#getAttributeDefinition <em>Attribute Definition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Attribute Definition</em>'.
	 * @see standardized_problem.ScenarioDef#getAttributeDefinition()
	 * @see #getScenarioDef()
	 * @generated
	 */
	EReference getScenarioDef_AttributeDefinition();

	/**
	 * Returns the meta object for the containment reference list '{@link standardized_problem.ScenarioDef#getTuple <em>Tuple</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Tuple</em>'.
	 * @see standardized_problem.ScenarioDef#getTuple()
	 * @see #getScenarioDef()
	 * @generated
	 */
	EReference getScenarioDef_Tuple();

	/**
	 * Returns the meta object for the containment reference list '{@link standardized_problem.ScenarioDef#getPerformanceMeasures <em>Performance Measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Performance Measures</em>'.
	 * @see standardized_problem.ScenarioDef#getPerformanceMeasures()
	 * @see #getScenarioDef()
	 * @generated
	 */
	EReference getScenarioDef_PerformanceMeasures();

	/**
	 * Returns the meta object for the containment reference list '{@link standardized_problem.ScenarioDef#getBenchmarkconstraint <em>Benchmarkconstraint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Benchmarkconstraint</em>'.
	 * @see standardized_problem.ScenarioDef#getBenchmarkconstraint()
	 * @see #getScenarioDef()
	 * @generated
	 */
	EReference getScenarioDef_Benchmarkconstraint();

	/**
	 * Returns the meta object for class '{@link standardized_problem.PerformanceMeasure <em>Performance Measure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Performance Measure</em>'.
	 * @see standardized_problem.PerformanceMeasure
	 * @generated
	 */
	EClass getPerformanceMeasure();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.PerformanceMeasure#getMetric <em>Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Metric</em>'.
	 * @see standardized_problem.PerformanceMeasure#getMetric()
	 * @see #getPerformanceMeasure()
	 * @generated
	 */
	EAttribute getPerformanceMeasure_Metric();

	/**
	 * Returns the meta object for class '{@link standardized_problem.DescriptorObject <em>Descriptor Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Descriptor Object</em>'.
	 * @see standardized_problem.DescriptorObject
	 * @generated
	 */
	EClass getDescriptorObject();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.DescriptorObject#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see standardized_problem.DescriptorObject#getLabel()
	 * @see #getDescriptorObject()
	 * @generated
	 */
	EAttribute getDescriptorObject_Label();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.DescriptorObject#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see standardized_problem.DescriptorObject#getDescription()
	 * @see #getDescriptorObject()
	 * @generated
	 */
	EAttribute getDescriptorObject_Description();

	/**
	 * Returns the meta object for class '{@link standardized_problem.EnvironmentVariable <em>Environment Variable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Environment Variable</em>'.
	 * @see standardized_problem.EnvironmentVariable
	 * @generated
	 */
	EClass getEnvironmentVariable();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.EnvironmentVariable#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see standardized_problem.EnvironmentVariable#getDescription()
	 * @see #getEnvironmentVariable()
	 * @generated
	 */
	EAttribute getEnvironmentVariable_Description();

	/**
	 * Returns the meta object for class '{@link standardized_problem.IScoreElement <em>IScore Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IScore Element</em>'.
	 * @see standardized_problem.IScoreElement
	 * @generated
	 */
	EClass getIScoreElement();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.IScoreElement#getScore <em>Score</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Score</em>'.
	 * @see standardized_problem.IScoreElement#getScore()
	 * @see #getIScoreElement()
	 * @generated
	 */
	EAttribute getIScoreElement_Score();

	/**
	 * Returns the meta object for class '{@link standardized_problem.IScore <em>IScore</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IScore</em>'.
	 * @see standardized_problem.IScore
	 * @generated
	 */
	EClass getIScore();

	/**
	 * Returns the meta object for the '{@link standardized_problem.IScore#calcScore(standardized_problem.IScoreElement) <em>Calc Score</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calc Score</em>' operation.
	 * @see standardized_problem.IScore#calcScore(standardized_problem.IScoreElement)
	 * @generated
	 */
	EOperation getIScore__CalcScore__IScoreElement();

	/**
	 * Returns the meta object for class '{@link standardized_problem.Tuple <em>Tuple</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tuple</em>'.
	 * @see standardized_problem.Tuple
	 * @generated
	 */
	EClass getTuple();

	/**
	 * Returns the meta object for the container reference '{@link standardized_problem.Tuple#getScenarioDef <em>Scenario Def</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Scenario Def</em>'.
	 * @see standardized_problem.Tuple#getScenarioDef()
	 * @see #getTuple()
	 * @generated
	 */
	EReference getTuple_ScenarioDef();

	/**
	 * Returns the meta object for the reference '{@link standardized_problem.Tuple#getCommServiceDef <em>Comm Service Def</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Comm Service Def</em>'.
	 * @see standardized_problem.Tuple#getCommServiceDef()
	 * @see #getTuple()
	 * @generated
	 */
	EReference getTuple_CommServiceDef();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.Tuple#getWeight <em>Weight</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Weight</em>'.
	 * @see standardized_problem.Tuple#getWeight()
	 * @see #getTuple()
	 * @generated
	 */
	EAttribute getTuple_Weight();

	/**
	 * Returns the meta object for the reference '{@link standardized_problem.Tuple#getCommObject <em>Comm Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Comm Object</em>'.
	 * @see standardized_problem.Tuple#getCommObject()
	 * @see #getTuple()
	 * @generated
	 */
	EReference getTuple_CommObject();

	/**
	 * Returns the meta object for the reference list '{@link standardized_problem.Tuple#getWeightedperfmeasure <em>Weightedperfmeasure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Weightedperfmeasure</em>'.
	 * @see standardized_problem.Tuple#getWeightedperfmeasure()
	 * @see #getTuple()
	 * @generated
	 */
	EReference getTuple_Weightedperfmeasure();

	/**
	 * Returns the meta object for the containment reference list '{@link standardized_problem.Tuple#getEnvVarVal <em>Env Var Val</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Env Var Val</em>'.
	 * @see standardized_problem.Tuple#getEnvVarVal()
	 * @see #getTuple()
	 * @generated
	 */
	EReference getTuple_EnvVarVal();

	/**
	 * Returns the meta object for class '{@link standardized_problem.WeightedPerfMeasure <em>Weighted Perf Measure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Weighted Perf Measure</em>'.
	 * @see standardized_problem.WeightedPerfMeasure
	 * @generated
	 */
	EClass getWeightedPerfMeasure();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.WeightedPerfMeasure#getWeight <em>Weight</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Weight</em>'.
	 * @see standardized_problem.WeightedPerfMeasure#getWeight()
	 * @see #getWeightedPerfMeasure()
	 * @generated
	 */
	EAttribute getWeightedPerfMeasure_Weight();

	/**
	 * Returns the meta object for the reference '{@link standardized_problem.WeightedPerfMeasure#getPerfMeasure <em>Perf Measure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Perf Measure</em>'.
	 * @see standardized_problem.WeightedPerfMeasure#getPerfMeasure()
	 * @see #getWeightedPerfMeasure()
	 * @generated
	 */
	EReference getWeightedPerfMeasure_PerfMeasure();

	/**
	 * Returns the meta object for class '{@link standardized_problem.EnvVarVal <em>Env Var Val</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Env Var Val</em>'.
	 * @see standardized_problem.EnvVarVal
	 * @generated
	 */
	EClass getEnvVarVal();

	/**
	 * Returns the meta object for the containment reference '{@link standardized_problem.EnvVarVal#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Value</em>'.
	 * @see standardized_problem.EnvVarVal#getValue()
	 * @see #getEnvVarVal()
	 * @generated
	 */
	EReference getEnvVarVal_Value();

	/**
	 * Returns the meta object for the reference '{@link standardized_problem.EnvVarVal#getEnvironmentVariable <em>Environment Variable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Environment Variable</em>'.
	 * @see standardized_problem.EnvVarVal#getEnvironmentVariable()
	 * @see #getEnvVarVal()
	 * @generated
	 */
	EReference getEnvVarVal_EnvironmentVariable();

	/**
	 * Returns the meta object for class '{@link standardized_problem.BenchmarkConstraint <em>Benchmark Constraint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Benchmark Constraint</em>'.
	 * @see standardized_problem.BenchmarkConstraint
	 * @generated
	 */
	EClass getBenchmarkConstraint();

	/**
	 * Returns the meta object for the attribute '{@link standardized_problem.BenchmarkConstraint#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see standardized_problem.BenchmarkConstraint#getDescription()
	 * @see #getBenchmarkConstraint()
	 * @generated
	 */
	EAttribute getBenchmarkConstraint_Description();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Standardized_problemFactory getStandardized_problemFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link standardized_problem.impl.StandardizedProblemImpl <em>Standardized Problem</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.StandardizedProblemImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getStandardizedProblem()
		 * @generated
		 */
		EClass STANDARDIZED_PROBLEM = eINSTANCE.getStandardizedProblem();

		/**
		 * The meta object literal for the '<em><b>Scenario Definitions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS = eINSTANCE.getStandardizedProblem_ScenarioDefinitions();

		/**
		 * The meta object literal for the '<em><b>Performance Criteria</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA = eINSTANCE.getStandardizedProblem_PerformanceCriteria();

		/**
		 * The meta object literal for the '<em><b>Comm Service Def</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STANDARDIZED_PROBLEM__COMM_SERVICE_DEF = eINSTANCE.getStandardizedProblem_CommServiceDef();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.ScenarioDefImpl <em>Scenario Def</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.ScenarioDefImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getScenarioDef()
		 * @generated
		 */
		EClass SCENARIO_DEF = eINSTANCE.getScenarioDef();

		/**
		 * The meta object literal for the '<em><b>Dimensions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO_DEF__DIMENSIONS = eINSTANCE.getScenarioDef_Dimensions();

		/**
		 * The meta object literal for the '<em><b>Comm Serv Def</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO_DEF__COMM_SERV_DEF = eINSTANCE.getScenarioDef_CommServDef();

		/**
		 * The meta object literal for the '<em><b>Weight</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SCENARIO_DEF__WEIGHT = eINSTANCE.getScenarioDef_Weight();

		/**
		 * The meta object literal for the '<em><b>Attribute Definition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO_DEF__ATTRIBUTE_DEFINITION = eINSTANCE.getScenarioDef_AttributeDefinition();

		/**
		 * The meta object literal for the '<em><b>Tuple</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO_DEF__TUPLE = eINSTANCE.getScenarioDef_Tuple();

		/**
		 * The meta object literal for the '<em><b>Performance Measures</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO_DEF__PERFORMANCE_MEASURES = eINSTANCE.getScenarioDef_PerformanceMeasures();

		/**
		 * The meta object literal for the '<em><b>Benchmarkconstraint</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCENARIO_DEF__BENCHMARKCONSTRAINT = eINSTANCE.getScenarioDef_Benchmarkconstraint();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.PerformanceMeasureImpl <em>Performance Measure</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.PerformanceMeasureImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getPerformanceMeasure()
		 * @generated
		 */
		EClass PERFORMANCE_MEASURE = eINSTANCE.getPerformanceMeasure();

		/**
		 * The meta object literal for the '<em><b>Metric</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERFORMANCE_MEASURE__METRIC = eINSTANCE.getPerformanceMeasure_Metric();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.DescriptorObjectImpl <em>Descriptor Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.DescriptorObjectImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getDescriptorObject()
		 * @generated
		 */
		EClass DESCRIPTOR_OBJECT = eINSTANCE.getDescriptorObject();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DESCRIPTOR_OBJECT__LABEL = eINSTANCE.getDescriptorObject_Label();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DESCRIPTOR_OBJECT__DESCRIPTION = eINSTANCE.getDescriptorObject_Description();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.EnvironmentVariableImpl <em>Environment Variable</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.EnvironmentVariableImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getEnvironmentVariable()
		 * @generated
		 */
		EClass ENVIRONMENT_VARIABLE = eINSTANCE.getEnvironmentVariable();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENVIRONMENT_VARIABLE__DESCRIPTION = eINSTANCE.getEnvironmentVariable_Description();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.IScoreElementImpl <em>IScore Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.IScoreElementImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getIScoreElement()
		 * @generated
		 */
		EClass ISCORE_ELEMENT = eINSTANCE.getIScoreElement();

		/**
		 * The meta object literal for the '<em><b>Score</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ISCORE_ELEMENT__SCORE = eINSTANCE.getIScoreElement_Score();

		/**
		 * The meta object literal for the '{@link standardized_problem.IScore <em>IScore</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.IScore
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getIScore()
		 * @generated
		 */
		EClass ISCORE = eINSTANCE.getIScore();

		/**
		 * The meta object literal for the '<em><b>Calc Score</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ISCORE___CALC_SCORE__ISCOREELEMENT = eINSTANCE.getIScore__CalcScore__IScoreElement();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.TupleImpl <em>Tuple</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.TupleImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getTuple()
		 * @generated
		 */
		EClass TUPLE = eINSTANCE.getTuple();

		/**
		 * The meta object literal for the '<em><b>Scenario Def</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TUPLE__SCENARIO_DEF = eINSTANCE.getTuple_ScenarioDef();

		/**
		 * The meta object literal for the '<em><b>Comm Service Def</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TUPLE__COMM_SERVICE_DEF = eINSTANCE.getTuple_CommServiceDef();

		/**
		 * The meta object literal for the '<em><b>Weight</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TUPLE__WEIGHT = eINSTANCE.getTuple_Weight();

		/**
		 * The meta object literal for the '<em><b>Comm Object</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TUPLE__COMM_OBJECT = eINSTANCE.getTuple_CommObject();

		/**
		 * The meta object literal for the '<em><b>Weightedperfmeasure</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TUPLE__WEIGHTEDPERFMEASURE = eINSTANCE.getTuple_Weightedperfmeasure();

		/**
		 * The meta object literal for the '<em><b>Env Var Val</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TUPLE__ENV_VAR_VAL = eINSTANCE.getTuple_EnvVarVal();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.WeightedPerfMeasureImpl <em>Weighted Perf Measure</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.WeightedPerfMeasureImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getWeightedPerfMeasure()
		 * @generated
		 */
		EClass WEIGHTED_PERF_MEASURE = eINSTANCE.getWeightedPerfMeasure();

		/**
		 * The meta object literal for the '<em><b>Weight</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEIGHTED_PERF_MEASURE__WEIGHT = eINSTANCE.getWeightedPerfMeasure_Weight();

		/**
		 * The meta object literal for the '<em><b>Perf Measure</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEIGHTED_PERF_MEASURE__PERF_MEASURE = eINSTANCE.getWeightedPerfMeasure_PerfMeasure();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.EnvVarValImpl <em>Env Var Val</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.EnvVarValImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getEnvVarVal()
		 * @generated
		 */
		EClass ENV_VAR_VAL = eINSTANCE.getEnvVarVal();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENV_VAR_VAL__VALUE = eINSTANCE.getEnvVarVal_Value();

		/**
		 * The meta object literal for the '<em><b>Environment Variable</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENV_VAR_VAL__ENVIRONMENT_VARIABLE = eINSTANCE.getEnvVarVal_EnvironmentVariable();

		/**
		 * The meta object literal for the '{@link standardized_problem.impl.BenchmarkConstraintImpl <em>Benchmark Constraint</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see standardized_problem.impl.BenchmarkConstraintImpl
		 * @see standardized_problem.impl.Standardized_problemPackageImpl#getBenchmarkConstraint()
		 * @generated
		 */
		EClass BENCHMARK_CONSTRAINT = eINSTANCE.getBenchmarkConstraint();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BENCHMARK_CONSTRAINT__DESCRIPTION = eINSTANCE.getBenchmarkConstraint_Description();

	}

} //Standardized_problemPackage
