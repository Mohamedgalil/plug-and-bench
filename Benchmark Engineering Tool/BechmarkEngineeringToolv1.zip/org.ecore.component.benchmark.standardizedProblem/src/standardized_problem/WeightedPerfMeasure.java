/**
 */
package standardized_problem;

import java.math.BigDecimal;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Weighted Perf Measure</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.WeightedPerfMeasure#getWeight <em>Weight</em>}</li>
 *   <li>{@link standardized_problem.WeightedPerfMeasure#getPerfMeasure <em>Perf Measure</em>}</li>
 * </ul>
 *
 * @see standardized_problem.Standardized_problemPackage#getWeightedPerfMeasure()
 * @model
 * @generated
 */
public interface WeightedPerfMeasure extends EObject {
	/**
	 * Returns the value of the '<em><b>Weight</b></em>' attribute.
	 * The default value is <code>"1.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Weight</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weight</em>' attribute.
	 * @see #setWeight(BigDecimal)
	 * @see standardized_problem.Standardized_problemPackage#getWeightedPerfMeasure_Weight()
	 * @model default="1.0"
	 * @generated
	 */
	BigDecimal getWeight();

	/**
	 * Sets the value of the '{@link standardized_problem.WeightedPerfMeasure#getWeight <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Weight</em>' attribute.
	 * @see #getWeight()
	 * @generated
	 */
	void setWeight(BigDecimal value);

	/**
	 * Returns the value of the '<em><b>Perf Measure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Perf Measure</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Perf Measure</em>' reference.
	 * @see #setPerfMeasure(PerformanceMeasure)
	 * @see standardized_problem.Standardized_problemPackage#getWeightedPerfMeasure_PerfMeasure()
	 * @model required="true"
	 * @generated
	 */
	PerformanceMeasure getPerfMeasure();

	/**
	 * Sets the value of the '{@link standardized_problem.WeightedPerfMeasure#getPerfMeasure <em>Perf Measure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Perf Measure</em>' reference.
	 * @see #getPerfMeasure()
	 * @generated
	 */
	void setPerfMeasure(PerformanceMeasure value);

} // WeightedPerfMeasure
