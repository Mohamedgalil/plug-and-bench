/**
 */
package standardized_problem;

import java.math.BigDecimal;

import org.eclipse.emf.common.util.EList;

import org.ecore.base.basicAttributes.AttributeDefinition;

import org.ecore.service.serviceDefinition.CommunicationServiceDefinition;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scenario Def</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A scenarioDefinition defines a range of scenario parameters in which a category of scenarios fall under.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.ScenarioDef#getDimensions <em>Dimensions</em>}</li>
 *   <li>{@link standardized_problem.ScenarioDef#getCommServDef <em>Comm Serv Def</em>}</li>
 *   <li>{@link standardized_problem.ScenarioDef#getWeight <em>Weight</em>}</li>
 *   <li>{@link standardized_problem.ScenarioDef#getAttributeDefinition <em>Attribute Definition</em>}</li>
 *   <li>{@link standardized_problem.ScenarioDef#getTuple <em>Tuple</em>}</li>
 *   <li>{@link standardized_problem.ScenarioDef#getPerformanceMeasures <em>Performance Measures</em>}</li>
 *   <li>{@link standardized_problem.ScenarioDef#getBenchmarkconstraint <em>Benchmarkconstraint</em>}</li>
 * </ul>
 *
 * @see standardized_problem.Standardized_problemPackage#getScenarioDef()
 * @model extendedMetaData="name='elements'"
 * @generated
 */
public interface ScenarioDef extends DescriptorObject, IScoreElement, IScore {
	/**
	 * Returns the value of the '<em><b>Dimensions</b></em>' containment reference list.
	 * The list contents are of type {@link standardized_problem.EnvironmentVariable}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Derived from commObject
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Dimensions</em>' containment reference list.
	 * @see standardized_problem.Standardized_problemPackage#getScenarioDef_Dimensions()
	 * @model containment="true"
	 * @generated
	 */
	EList<EnvironmentVariable> getDimensions();

	/**
	 * Returns the value of the '<em><b>Comm Serv Def</b></em>' reference list.
	 * The list contents are of type {@link org.ecore.service.serviceDefinition.CommunicationServiceDefinition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Specifies the commServDef to the external components which are of interest to the respective ScenarioDef. A contained tuple can be sent to one externalComponents.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Comm Serv Def</em>' reference list.
	 * @see standardized_problem.Standardized_problemPackage#getScenarioDef_CommServDef()
	 * @model
	 * @generated
	 */
	EList<CommunicationServiceDefinition> getCommServDef();

	/**
	 * Returns the value of the '<em><b>Weight</b></em>' attribute.
	 * The default value is <code>"1.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Weight</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weight</em>' attribute.
	 * @see #setWeight(BigDecimal)
	 * @see standardized_problem.Standardized_problemPackage#getScenarioDef_Weight()
	 * @model default="1.0"
	 * @generated
	 */
	BigDecimal getWeight();

	/**
	 * Sets the value of the '{@link standardized_problem.ScenarioDef#getWeight <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Weight</em>' attribute.
	 * @see #getWeight()
	 * @generated
	 */
	void setWeight(BigDecimal value);

	/**
	 * Returns the value of the '<em><b>Attribute Definition</b></em>' reference list.
	 * The list contents are of type {@link org.ecore.base.basicAttributes.AttributeDefinition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Specifies the dimensions supported in this ScenarioDef. To be derived from the CommunicationServiceDefinition.CommPattern.CommObject
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Attribute Definition</em>' reference list.
	 * @see standardized_problem.Standardized_problemPackage#getScenarioDef_AttributeDefinition()
	 * @model derived="true"
	 * @generated
	 */
	EList<AttributeDefinition> getAttributeDefinition();

	/**
	 * Returns the value of the '<em><b>Tuple</b></em>' containment reference list.
	 * The list contents are of type {@link standardized_problem.Tuple}.
	 * It is bidirectional and its opposite is '{@link standardized_problem.Tuple#getScenarioDef <em>Scenario Def</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tuple</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tuple</em>' containment reference list.
	 * @see standardized_problem.Standardized_problemPackage#getScenarioDef_Tuple()
	 * @see standardized_problem.Tuple#getScenarioDef
	 * @model opposite="scenarioDef" containment="true"
	 * @generated
	 */
	EList<Tuple> getTuple();

	/**
	 * Returns the value of the '<em><b>Performance Measures</b></em>' containment reference list.
	 * The list contents are of type {@link standardized_problem.WeightedPerfMeasure}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Performance Measures</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Performance Measures</em>' containment reference list.
	 * @see standardized_problem.Standardized_problemPackage#getScenarioDef_PerformanceMeasures()
	 * @model containment="true"
	 * @generated
	 */
	EList<WeightedPerfMeasure> getPerformanceMeasures();

	/**
	 * Returns the value of the '<em><b>Benchmarkconstraint</b></em>' containment reference list.
	 * The list contents are of type {@link standardized_problem.BenchmarkConstraint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Benchmarkconstraint</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Benchmarkconstraint</em>' containment reference list.
	 * @see standardized_problem.Standardized_problemPackage#getScenarioDef_Benchmarkconstraint()
	 * @model containment="true"
	 * @generated
	 */
	EList<BenchmarkConstraint> getBenchmarkconstraint();

} // ScenarioDef
