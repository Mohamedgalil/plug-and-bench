/**
 */
package standardized_problem.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import standardized_problem.EnvVarVal;
import standardized_problem.Standardized_problemFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Env Var Val</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class EnvVarValTest extends TestCase {

	/**
	 * The fixture for this Env Var Val test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EnvVarVal fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(EnvVarValTest.class);
	}

	/**
	 * Constructs a new Env Var Val test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnvVarValTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Env Var Val test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(EnvVarVal fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Env Var Val test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EnvVarVal getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Standardized_problemFactory.eINSTANCE.createEnvVarVal());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //EnvVarValTest
