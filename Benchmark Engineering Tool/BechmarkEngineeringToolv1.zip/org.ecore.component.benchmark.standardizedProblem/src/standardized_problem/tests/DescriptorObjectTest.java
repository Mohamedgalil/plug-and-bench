/**
 */
package standardized_problem.tests;

import junit.framework.TestCase;

import standardized_problem.DescriptorObject;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Descriptor Object</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class DescriptorObjectTest extends TestCase {

	/**
	 * The fixture for this Descriptor Object test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DescriptorObject fixture = null;

	/**
	 * Constructs a new Descriptor Object test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DescriptorObjectTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Descriptor Object test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(DescriptorObject fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Descriptor Object test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DescriptorObject getFixture() {
		return fixture;
	}

} //DescriptorObjectTest
