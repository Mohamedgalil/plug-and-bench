/**
 */
package standardized_problem.tests;

import junit.framework.TestCase;

import standardized_problem.IScore;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>IScore</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link standardized_problem.IScore#calcScore(standardized_problem.IScoreElement) <em>Calc Score</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public abstract class IScoreTest extends TestCase {

	/**
	 * The fixture for this IScore test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IScore fixture = null;

	/**
	 * Constructs a new IScore test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IScoreTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this IScore test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(IScore fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this IScore test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IScore getFixture() {
		return fixture;
	}

	/**
	 * Tests the '{@link standardized_problem.IScore#calcScore(standardized_problem.IScoreElement) <em>Calc Score</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.IScore#calcScore(standardized_problem.IScoreElement)
	 * @generated
	 */
	public void testCalcScore__IScoreElement() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //IScoreTest
