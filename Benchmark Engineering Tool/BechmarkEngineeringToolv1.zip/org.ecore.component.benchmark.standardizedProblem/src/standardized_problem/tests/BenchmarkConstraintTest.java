/**
 */
package standardized_problem.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import standardized_problem.BenchmarkConstraint;
import standardized_problem.Standardized_problemFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Benchmark Constraint</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class BenchmarkConstraintTest extends TestCase {

	/**
	 * The fixture for this Benchmark Constraint test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BenchmarkConstraint fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(BenchmarkConstraintTest.class);
	}

	/**
	 * Constructs a new Benchmark Constraint test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BenchmarkConstraintTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Benchmark Constraint test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(BenchmarkConstraint fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Benchmark Constraint test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BenchmarkConstraint getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Standardized_problemFactory.eINSTANCE.createBenchmarkConstraint());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //BenchmarkConstraintTest
