/**
 */
package standardized_problem.tests;

import junit.textui.TestRunner;

import standardized_problem.PerformanceMeasure;
import standardized_problem.Standardized_problemFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Performance Measure</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class PerformanceMeasureTest extends DescriptorObjectTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(PerformanceMeasureTest.class);
	}

	/**
	 * Constructs a new Performance Measure test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformanceMeasureTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Performance Measure test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected PerformanceMeasure getFixture() {
		return (PerformanceMeasure)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Standardized_problemFactory.eINSTANCE.createPerformanceMeasure());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //PerformanceMeasureTest
