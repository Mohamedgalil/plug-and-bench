/**
 */
package standardized_problem.tests;

import junit.framework.TestCase;

import standardized_problem.IScoreElement;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>IScore Element</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class IScoreElementTest extends TestCase {

	/**
	 * The fixture for this IScore Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IScoreElement fixture = null;

	/**
	 * Constructs a new IScore Element test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IScoreElementTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this IScore Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(IScoreElement fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this IScore Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IScoreElement getFixture() {
		return fixture;
	}

} //IScoreElementTest
