/**
 */
package standardized_problem.tests;

import junit.textui.TestRunner;

import standardized_problem.StandardizedProblem;
import standardized_problem.Standardized_problemFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Standardized Problem</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link standardized_problem.IScore#calcScore(standardized_problem.IScoreElement) <em>Calc Score</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class StandardizedProblemTest extends DescriptorObjectTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(StandardizedProblemTest.class);
	}

	/**
	 * Constructs a new Standardized Problem test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StandardizedProblemTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Standardized Problem test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected StandardizedProblem getFixture() {
		return (StandardizedProblem)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Standardized_problemFactory.eINSTANCE.createStandardizedProblem());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link standardized_problem.IScore#calcScore(standardized_problem.IScoreElement) <em>Calc Score</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.IScore#calcScore(standardized_problem.IScoreElement)
	 * @generated
	 */
	public void testCalcScore__IScoreElement() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //StandardizedProblemTest
