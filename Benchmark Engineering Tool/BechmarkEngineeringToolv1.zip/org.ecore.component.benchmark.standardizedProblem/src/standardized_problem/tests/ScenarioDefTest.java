/**
 */
package standardized_problem.tests;

import junit.textui.TestRunner;

import standardized_problem.ScenarioDef;
import standardized_problem.Standardized_problemFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Scenario Def</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are tested:
 * <ul>
 *   <li>{@link standardized_problem.ScenarioDef#getAttributeDefinition() <em>Attribute Definition</em>}</li>
 * </ul>
 * </p>
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link standardized_problem.IScore#calcScore(standardized_problem.IScoreElement) <em>Calc Score</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class ScenarioDefTest extends DescriptorObjectTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ScenarioDefTest.class);
	}

	/**
	 * Constructs a new Scenario Def test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ScenarioDefTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Scenario Def test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ScenarioDef getFixture() {
		return (ScenarioDef)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Standardized_problemFactory.eINSTANCE.createScenarioDef());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link standardized_problem.ScenarioDef#getAttributeDefinition() <em>Attribute Definition</em>}' feature getter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.ScenarioDef#getAttributeDefinition()
	 * @generated
	 */
	public void testGetAttributeDefinition() {
		// TODO: implement this feature getter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link standardized_problem.IScore#calcScore(standardized_problem.IScoreElement) <em>Calc Score</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see standardized_problem.IScore#calcScore(standardized_problem.IScoreElement)
	 * @generated
	 */
	public void testCalcScore__IScoreElement() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //ScenarioDefTest
