/**
 */
package standardized_problem.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import standardized_problem.Standardized_problemFactory;
import standardized_problem.WeightedPerfMeasure;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Weighted Perf Measure</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class WeightedPerfMeasureTest extends TestCase {

	/**
	 * The fixture for this Weighted Perf Measure test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WeightedPerfMeasure fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(WeightedPerfMeasureTest.class);
	}

	/**
	 * Constructs a new Weighted Perf Measure test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WeightedPerfMeasureTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Weighted Perf Measure test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(WeightedPerfMeasure fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Weighted Perf Measure test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WeightedPerfMeasure getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Standardized_problemFactory.eINSTANCE.createWeightedPerfMeasure());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //WeightedPerfMeasureTest
