/**
 */
package standardized_problem;

import java.math.BigDecimal;

import org.eclipse.emf.common.util.EList;

import org.ecore.service.communicationObject.CommunicationObject;

import org.ecore.service.serviceDefinition.CommunicationServiceDefinition;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tuple</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Mapped to communication Object and will contain all the dimensions sated in the ScenarioDef. 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.Tuple#getScenarioDef <em>Scenario Def</em>}</li>
 *   <li>{@link standardized_problem.Tuple#getCommServiceDef <em>Comm Service Def</em>}</li>
 *   <li>{@link standardized_problem.Tuple#getWeight <em>Weight</em>}</li>
 *   <li>{@link standardized_problem.Tuple#getCommObject <em>Comm Object</em>}</li>
 *   <li>{@link standardized_problem.Tuple#getWeightedperfmeasure <em>Weightedperfmeasure</em>}</li>
 *   <li>{@link standardized_problem.Tuple#getEnvVarVal <em>Env Var Val</em>}</li>
 * </ul>
 *
 * @see standardized_problem.Standardized_problemPackage#getTuple()
 * @model
 * @generated
 */
public interface Tuple extends DescriptorObject {
	/**
	 * Returns the value of the '<em><b>Scenario Def</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link standardized_problem.ScenarioDef#getTuple <em>Tuple</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scenario Def</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scenario Def</em>' container reference.
	 * @see #setScenarioDef(ScenarioDef)
	 * @see standardized_problem.Standardized_problemPackage#getTuple_ScenarioDef()
	 * @see standardized_problem.ScenarioDef#getTuple
	 * @model opposite="tuple" required="true" transient="false"
	 * @generated
	 */
	ScenarioDef getScenarioDef();

	/**
	 * Sets the value of the '{@link standardized_problem.Tuple#getScenarioDef <em>Scenario Def</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Scenario Def</em>' container reference.
	 * @see #getScenarioDef()
	 * @generated
	 */
	void setScenarioDef(ScenarioDef value);

	/**
	 * Returns the value of the '<em><b>Comm Service Def</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The communicationServiceDefinition which the tuple will be sent on. A tuple can be only sent to one component. Duplicate tuples can be created to be sent to multiple components.
	 * OCL: Tuple.commServDef should be subset of Tuple.ScenarioDef.commServiceDef.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Comm Service Def</em>' reference.
	 * @see #setCommServiceDef(CommunicationServiceDefinition)
	 * @see standardized_problem.Standardized_problemPackage#getTuple_CommServiceDef()
	 * @model
	 * @generated
	 */
	CommunicationServiceDefinition getCommServiceDef();

	/**
	 * Sets the value of the '{@link standardized_problem.Tuple#getCommServiceDef <em>Comm Service Def</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Comm Service Def</em>' reference.
	 * @see #getCommServiceDef()
	 * @generated
	 */
	void setCommServiceDef(CommunicationServiceDefinition value);

	/**
	 * Returns the value of the '<em><b>Weight</b></em>' attribute.
	 * The default value is <code>"1.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Weight</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weight</em>' attribute.
	 * @see #setWeight(BigDecimal)
	 * @see standardized_problem.Standardized_problemPackage#getTuple_Weight()
	 * @model default="1.0"
	 * @generated
	 */
	BigDecimal getWeight();

	/**
	 * Sets the value of the '{@link standardized_problem.Tuple#getWeight <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Weight</em>' attribute.
	 * @see #getWeight()
	 * @generated
	 */
	void setWeight(BigDecimal value);

	/**
	 * Returns the value of the '<em><b>Comm Object</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A Tuple will be mapped to CommunicationObject to be sent to externalComponents (if necessary) through Tuple.commServiceDef.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Comm Object</em>' reference.
	 * @see #setCommObject(CommunicationObject)
	 * @see standardized_problem.Standardized_problemPackage#getTuple_CommObject()
	 * @model
	 * @generated
	 */
	CommunicationObject getCommObject();

	/**
	 * Sets the value of the '{@link standardized_problem.Tuple#getCommObject <em>Comm Object</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Comm Object</em>' reference.
	 * @see #getCommObject()
	 * @generated
	 */
	void setCommObject(CommunicationObject value);

	/**
	 * Returns the value of the '<em><b>Weightedperfmeasure</b></em>' reference list.
	 * The list contents are of type {@link standardized_problem.WeightedPerfMeasure}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Weightedperfmeasure</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weightedperfmeasure</em>' reference list.
	 * @see standardized_problem.Standardized_problemPackage#getTuple_Weightedperfmeasure()
	 * @model
	 * @generated
	 */
	EList<WeightedPerfMeasure> getWeightedperfmeasure();

	/**
	 * Returns the value of the '<em><b>Env Var Val</b></em>' containment reference list.
	 * The list contents are of type {@link standardized_problem.EnvVarVal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Env Var Val</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Env Var Val</em>' containment reference list.
	 * @see standardized_problem.Standardized_problemPackage#getTuple_EnvVarVal()
	 * @model containment="true"
	 * @generated
	 */
	EList<EnvVarVal> getEnvVarVal();

} // Tuple
