/**
 */
package standardized_problem;

import org.ecore.base.basicAttributes.AttributeDefinition;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Environment Variable</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The parameters defining the scope/range of the ScenarioDefinition. The dimensions form the bases for querying databases + creating database (by database provider). Note that Dimension represents the scenarioDefinition dimensions, not the scenario data dimensions (e.g. for screwhole localizer, the ScenarioDefinition dimension can be Illumination, and the scenario data are images with different illuminations)
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.EnvironmentVariable#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @see standardized_problem.Standardized_problemPackage#getEnvironmentVariable()
 * @model
 * @generated
 */
public interface EnvironmentVariable extends AttributeDefinition {
	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Textual Description of the extending class. For each child class, the following descriptor is expected:
	 * - StandardizedProblem: textual description of the problem including the environment, supported sensors, output report, benchmark limitations, scoring mechanisms, performance criteria, etc. It describes the hole benchmark model textually. Example: Screwhole localizer benchmark benchmarks the screwhole localization components in the given environment "Factory environment", using the following sensors 3D Camera, etc. The supported Databases should have the following tables: "noise, light_conditions, etc." or should implement an interface to be queried for these variables.
	 * - ProblemScenarioDefinition: describes the scenario, with range of variables
	 * - Performance Criteria: describes how the performance can be assessed, and what is the physical thing that measured. Each performance criteria has a metric.
	 * - ConfigParameter: describes why do we measure this parameter.
	 * -
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see standardized_problem.Standardized_problemPackage#getEnvironmentVariable_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link standardized_problem.EnvironmentVariable#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

} // EnvironmentVariable
