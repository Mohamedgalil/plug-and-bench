/**
 */
package standardized_problem;

import org.eclipse.emf.ecore.EObject;

import org.ecore.base.basicAttributes.AbstractValue;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Env Var Val</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.EnvVarVal#getValue <em>Value</em>}</li>
 *   <li>{@link standardized_problem.EnvVarVal#getEnvironmentVariable <em>Environment Variable</em>}</li>
 * </ul>
 *
 * @see standardized_problem.Standardized_problemPackage#getEnvVarVal()
 * @model
 * @generated
 */
public interface EnvVarVal extends EObject {
	/**
	 * Returns the value of the '<em><b>Value</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' containment reference.
	 * @see #setValue(AbstractValue)
	 * @see standardized_problem.Standardized_problemPackage#getEnvVarVal_Value()
	 * @model containment="true"
	 * @generated
	 */
	AbstractValue getValue();

	/**
	 * Sets the value of the '{@link standardized_problem.EnvVarVal#getValue <em>Value</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' containment reference.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(AbstractValue value);

	/**
	 * Returns the value of the '<em><b>Environment Variable</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Environment Variable</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Environment Variable</em>' reference.
	 * @see #setEnvironmentVariable(EnvironmentVariable)
	 * @see standardized_problem.Standardized_problemPackage#getEnvVarVal_EnvironmentVariable()
	 * @model required="true"
	 * @generated
	 */
	EnvironmentVariable getEnvironmentVariable();

	/**
	 * Sets the value of the '{@link standardized_problem.EnvVarVal#getEnvironmentVariable <em>Environment Variable</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Environment Variable</em>' reference.
	 * @see #getEnvironmentVariable()
	 * @generated
	 */
	void setEnvironmentVariable(EnvironmentVariable value);

} // EnvVarVal
