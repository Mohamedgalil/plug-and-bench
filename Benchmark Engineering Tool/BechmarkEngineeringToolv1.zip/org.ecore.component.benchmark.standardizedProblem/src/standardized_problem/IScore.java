/**
 */
package standardized_problem;

import java.math.BigDecimal;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IScore</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see standardized_problem.Standardized_problemPackage#getIScore()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface IScore extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	BigDecimal calcScore(IScoreElement scoreElement);

} // IScore
