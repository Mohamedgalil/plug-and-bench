/**
 */
package standardized_problem.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import org.ecore.base.basicAttributes.AttributeDefinition;

import standardized_problem.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see standardized_problem.Standardized_problemPackage
 * @generated
 */
public class Standardized_problemSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Standardized_problemPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Standardized_problemSwitch() {
		if (modelPackage == null) {
			modelPackage = Standardized_problemPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case Standardized_problemPackage.STANDARDIZED_PROBLEM: {
				StandardizedProblem standardizedProblem = (StandardizedProblem)theEObject;
				T result = caseStandardizedProblem(standardizedProblem);
				if (result == null) result = caseDescriptorObject(standardizedProblem);
				if (result == null) result = caseIScoreElement(standardizedProblem);
				if (result == null) result = caseIScore(standardizedProblem);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.SCENARIO_DEF: {
				ScenarioDef scenarioDef = (ScenarioDef)theEObject;
				T result = caseScenarioDef(scenarioDef);
				if (result == null) result = caseDescriptorObject(scenarioDef);
				if (result == null) result = caseIScoreElement(scenarioDef);
				if (result == null) result = caseIScore(scenarioDef);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.PERFORMANCE_MEASURE: {
				PerformanceMeasure performanceMeasure = (PerformanceMeasure)theEObject;
				T result = casePerformanceMeasure(performanceMeasure);
				if (result == null) result = caseDescriptorObject(performanceMeasure);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.DESCRIPTOR_OBJECT: {
				DescriptorObject descriptorObject = (DescriptorObject)theEObject;
				T result = caseDescriptorObject(descriptorObject);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.ENVIRONMENT_VARIABLE: {
				EnvironmentVariable environmentVariable = (EnvironmentVariable)theEObject;
				T result = caseEnvironmentVariable(environmentVariable);
				if (result == null) result = caseAttributeDefinition(environmentVariable);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.ISCORE_ELEMENT: {
				IScoreElement iScoreElement = (IScoreElement)theEObject;
				T result = caseIScoreElement(iScoreElement);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.ISCORE: {
				IScore iScore = (IScore)theEObject;
				T result = caseIScore(iScore);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.TUPLE: {
				Tuple tuple = (Tuple)theEObject;
				T result = caseTuple(tuple);
				if (result == null) result = caseDescriptorObject(tuple);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE: {
				WeightedPerfMeasure weightedPerfMeasure = (WeightedPerfMeasure)theEObject;
				T result = caseWeightedPerfMeasure(weightedPerfMeasure);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.ENV_VAR_VAL: {
				EnvVarVal envVarVal = (EnvVarVal)theEObject;
				T result = caseEnvVarVal(envVarVal);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Standardized_problemPackage.BENCHMARK_CONSTRAINT: {
				BenchmarkConstraint benchmarkConstraint = (BenchmarkConstraint)theEObject;
				T result = caseBenchmarkConstraint(benchmarkConstraint);
				if (result == null) result = caseAttributeDefinition(benchmarkConstraint);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Standardized Problem</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Standardized Problem</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStandardizedProblem(StandardizedProblem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Scenario Def</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Scenario Def</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseScenarioDef(ScenarioDef object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Performance Measure</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Performance Measure</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePerformanceMeasure(PerformanceMeasure object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Descriptor Object</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Descriptor Object</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDescriptorObject(DescriptorObject object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Environment Variable</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Environment Variable</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnvironmentVariable(EnvironmentVariable object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>IScore Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>IScore Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIScoreElement(IScoreElement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>IScore</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>IScore</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIScore(IScore object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tuple</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tuple</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTuple(Tuple object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Weighted Perf Measure</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Weighted Perf Measure</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWeightedPerfMeasure(WeightedPerfMeasure object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Env Var Val</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Env Var Val</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnvVarVal(EnvVarVal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Benchmark Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Benchmark Constraint</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBenchmarkConstraint(BenchmarkConstraint object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attribute Definition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attribute Definition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttributeDefinition(AttributeDefinition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //Standardized_problemSwitch
