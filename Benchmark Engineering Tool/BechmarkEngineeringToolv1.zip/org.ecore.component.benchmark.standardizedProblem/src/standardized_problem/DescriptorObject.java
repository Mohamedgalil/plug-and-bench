/**
 */
package standardized_problem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Descriptor Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.DescriptorObject#getLabel <em>Label</em>}</li>
 *   <li>{@link standardized_problem.DescriptorObject#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @see standardized_problem.Standardized_problemPackage#getDescriptorObject()
 * @model abstract="true"
 * @generated
 */
public interface DescriptorObject extends EObject {
	/**
	 * Returns the value of the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The label of the respective element.
	 * 
	 * - metric: states the label, e.g. "cm"
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Label</em>' attribute.
	 * @see #setLabel(String)
	 * @see standardized_problem.Standardized_problemPackage#getDescriptorObject_Label()
	 * @model
	 * @generated
	 */
	String getLabel();

	/**
	 * Sets the value of the '{@link standardized_problem.DescriptorObject#getLabel <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' attribute.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Textual Description of the extending class. For each child class, the following descriptor is expected:
	 * - StandardizedProblem: textual description of the problem including the environment, supported sensors, output report, benchmark limitations, scoring mechanisms, performance criteria, etc. It describes the hole benchmark model textually. Example: Screwhole localizer benchmark benchmarks the screwhole localization components in the given environment "Factory environment", using the following sensors 3D Camera, etc. The supported Databases should have the following tables: "noise, light_conditions, etc." or should implement an interface to be queried for these variables.
	 * - ProblemScenarioDefinition: describes the scenario, with range of variables
	 * - Performance Criteria: describes how the performance can be assessed, and what is the physical thing that measured. Each performance criteria has a metric.
	 * - ConfigParameter: describes why do we measure this parameter.
	 * -
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see standardized_problem.Standardized_problemPackage#getDescriptorObject_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link standardized_problem.DescriptorObject#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

} // DescriptorObject
