/**
 */
package standardized_problem.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.ecore.base.basicAttributes.AbstractValue;

import standardized_problem.EnvVarVal;
import standardized_problem.EnvironmentVariable;
import standardized_problem.Standardized_problemPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Env Var Val</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.impl.EnvVarValImpl#getValue <em>Value</em>}</li>
 *   <li>{@link standardized_problem.impl.EnvVarValImpl#getEnvironmentVariable <em>Environment Variable</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EnvVarValImpl extends MinimalEObjectImpl.Container implements EnvVarVal {
	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected AbstractValue value;

	/**
	 * The cached value of the '{@link #getEnvironmentVariable() <em>Environment Variable</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnvironmentVariable()
	 * @generated
	 * @ordered
	 */
	protected EnvironmentVariable environmentVariable;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EnvVarValImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Standardized_problemPackage.Literals.ENV_VAR_VAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractValue getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetValue(AbstractValue newValue, NotificationChain msgs) {
		AbstractValue oldValue = value;
		value = newValue;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.ENV_VAR_VAL__VALUE, oldValue, newValue);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(AbstractValue newValue) {
		if (newValue != value) {
			NotificationChain msgs = null;
			if (value != null)
				msgs = ((InternalEObject)value).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Standardized_problemPackage.ENV_VAR_VAL__VALUE, null, msgs);
			if (newValue != null)
				msgs = ((InternalEObject)newValue).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Standardized_problemPackage.ENV_VAR_VAL__VALUE, null, msgs);
			msgs = basicSetValue(newValue, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.ENV_VAR_VAL__VALUE, newValue, newValue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnvironmentVariable getEnvironmentVariable() {
		if (environmentVariable != null && environmentVariable.eIsProxy()) {
			InternalEObject oldEnvironmentVariable = (InternalEObject)environmentVariable;
			environmentVariable = (EnvironmentVariable)eResolveProxy(oldEnvironmentVariable);
			if (environmentVariable != oldEnvironmentVariable) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Standardized_problemPackage.ENV_VAR_VAL__ENVIRONMENT_VARIABLE, oldEnvironmentVariable, environmentVariable));
			}
		}
		return environmentVariable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnvironmentVariable basicGetEnvironmentVariable() {
		return environmentVariable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnvironmentVariable(EnvironmentVariable newEnvironmentVariable) {
		EnvironmentVariable oldEnvironmentVariable = environmentVariable;
		environmentVariable = newEnvironmentVariable;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.ENV_VAR_VAL__ENVIRONMENT_VARIABLE, oldEnvironmentVariable, environmentVariable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Standardized_problemPackage.ENV_VAR_VAL__VALUE:
				return basicSetValue(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Standardized_problemPackage.ENV_VAR_VAL__VALUE:
				return getValue();
			case Standardized_problemPackage.ENV_VAR_VAL__ENVIRONMENT_VARIABLE:
				if (resolve) return getEnvironmentVariable();
				return basicGetEnvironmentVariable();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Standardized_problemPackage.ENV_VAR_VAL__VALUE:
				setValue((AbstractValue)newValue);
				return;
			case Standardized_problemPackage.ENV_VAR_VAL__ENVIRONMENT_VARIABLE:
				setEnvironmentVariable((EnvironmentVariable)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.ENV_VAR_VAL__VALUE:
				setValue((AbstractValue)null);
				return;
			case Standardized_problemPackage.ENV_VAR_VAL__ENVIRONMENT_VARIABLE:
				setEnvironmentVariable((EnvironmentVariable)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.ENV_VAR_VAL__VALUE:
				return value != null;
			case Standardized_problemPackage.ENV_VAR_VAL__ENVIRONMENT_VARIABLE:
				return environmentVariable != null;
		}
		return super.eIsSet(featureID);
	}

} //EnvVarValImpl
