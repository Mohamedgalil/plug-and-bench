/**
 */
package standardized_problem.impl;

import java.math.BigDecimal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import standardized_problem.PerformanceMeasure;
import standardized_problem.Standardized_problemPackage;
import standardized_problem.WeightedPerfMeasure;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Weighted Perf Measure</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.impl.WeightedPerfMeasureImpl#getWeight <em>Weight</em>}</li>
 *   <li>{@link standardized_problem.impl.WeightedPerfMeasureImpl#getPerfMeasure <em>Perf Measure</em>}</li>
 * </ul>
 *
 * @generated
 */
public class WeightedPerfMeasureImpl extends MinimalEObjectImpl.Container implements WeightedPerfMeasure {
	/**
	 * The default value of the '{@link #getWeight() <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeight()
	 * @generated
	 * @ordered
	 */
	protected static final BigDecimal WEIGHT_EDEFAULT = new BigDecimal("1.0");

	/**
	 * The cached value of the '{@link #getWeight() <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeight()
	 * @generated
	 * @ordered
	 */
	protected BigDecimal weight = WEIGHT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPerfMeasure() <em>Perf Measure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPerfMeasure()
	 * @generated
	 * @ordered
	 */
	protected PerformanceMeasure perfMeasure;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WeightedPerfMeasureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Standardized_problemPackage.Literals.WEIGHTED_PERF_MEASURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal getWeight() {
		return weight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWeight(BigDecimal newWeight) {
		BigDecimal oldWeight = weight;
		weight = newWeight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.WEIGHTED_PERF_MEASURE__WEIGHT, oldWeight, weight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformanceMeasure getPerfMeasure() {
		if (perfMeasure != null && perfMeasure.eIsProxy()) {
			InternalEObject oldPerfMeasure = (InternalEObject)perfMeasure;
			perfMeasure = (PerformanceMeasure)eResolveProxy(oldPerfMeasure);
			if (perfMeasure != oldPerfMeasure) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Standardized_problemPackage.WEIGHTED_PERF_MEASURE__PERF_MEASURE, oldPerfMeasure, perfMeasure));
			}
		}
		return perfMeasure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformanceMeasure basicGetPerfMeasure() {
		return perfMeasure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPerfMeasure(PerformanceMeasure newPerfMeasure) {
		PerformanceMeasure oldPerfMeasure = perfMeasure;
		perfMeasure = newPerfMeasure;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.WEIGHTED_PERF_MEASURE__PERF_MEASURE, oldPerfMeasure, perfMeasure));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE__WEIGHT:
				return getWeight();
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE__PERF_MEASURE:
				if (resolve) return getPerfMeasure();
				return basicGetPerfMeasure();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE__WEIGHT:
				setWeight((BigDecimal)newValue);
				return;
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE__PERF_MEASURE:
				setPerfMeasure((PerformanceMeasure)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE__WEIGHT:
				setWeight(WEIGHT_EDEFAULT);
				return;
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE__PERF_MEASURE:
				setPerfMeasure((PerformanceMeasure)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE__WEIGHT:
				return WEIGHT_EDEFAULT == null ? weight != null : !WEIGHT_EDEFAULT.equals(weight);
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE__PERF_MEASURE:
				return perfMeasure != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (weight: ");
		result.append(weight);
		result.append(')');
		return result.toString();
	}

} //WeightedPerfMeasureImpl
