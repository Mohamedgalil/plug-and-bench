/**
 */
package standardized_problem.impl;

import java.math.BigDecimal;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import org.ecore.service.communicationObject.CommunicationObject;

import org.ecore.service.serviceDefinition.CommunicationServiceDefinition;

import standardized_problem.EnvVarVal;
import standardized_problem.ScenarioDef;
import standardized_problem.Standardized_problemPackage;
import standardized_problem.Tuple;
import standardized_problem.WeightedPerfMeasure;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tuple</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.impl.TupleImpl#getScenarioDef <em>Scenario Def</em>}</li>
 *   <li>{@link standardized_problem.impl.TupleImpl#getCommServiceDef <em>Comm Service Def</em>}</li>
 *   <li>{@link standardized_problem.impl.TupleImpl#getWeight <em>Weight</em>}</li>
 *   <li>{@link standardized_problem.impl.TupleImpl#getCommObject <em>Comm Object</em>}</li>
 *   <li>{@link standardized_problem.impl.TupleImpl#getWeightedperfmeasure <em>Weightedperfmeasure</em>}</li>
 *   <li>{@link standardized_problem.impl.TupleImpl#getEnvVarVal <em>Env Var Val</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TupleImpl extends DescriptorObjectImpl implements Tuple {
	/**
	 * The cached value of the '{@link #getCommServiceDef() <em>Comm Service Def</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommServiceDef()
	 * @generated
	 * @ordered
	 */
	protected CommunicationServiceDefinition commServiceDef;

	/**
	 * The default value of the '{@link #getWeight() <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeight()
	 * @generated
	 * @ordered
	 */
	protected static final BigDecimal WEIGHT_EDEFAULT = new BigDecimal("1.0");

	/**
	 * The cached value of the '{@link #getWeight() <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeight()
	 * @generated
	 * @ordered
	 */
	protected BigDecimal weight = WEIGHT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCommObject() <em>Comm Object</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommObject()
	 * @generated
	 * @ordered
	 */
	protected CommunicationObject commObject;

	/**
	 * The cached value of the '{@link #getWeightedperfmeasure() <em>Weightedperfmeasure</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeightedperfmeasure()
	 * @generated
	 * @ordered
	 */
	protected EList<WeightedPerfMeasure> weightedperfmeasure;

	/**
	 * The cached value of the '{@link #getEnvVarVal() <em>Env Var Val</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnvVarVal()
	 * @generated
	 * @ordered
	 */
	protected EList<EnvVarVal> envVarVal;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TupleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Standardized_problemPackage.Literals.TUPLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ScenarioDef getScenarioDef() {
		if (eContainerFeatureID() != Standardized_problemPackage.TUPLE__SCENARIO_DEF) return null;
		return (ScenarioDef)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetScenarioDef(ScenarioDef newScenarioDef, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newScenarioDef, Standardized_problemPackage.TUPLE__SCENARIO_DEF, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScenarioDef(ScenarioDef newScenarioDef) {
		if (newScenarioDef != eInternalContainer() || (eContainerFeatureID() != Standardized_problemPackage.TUPLE__SCENARIO_DEF && newScenarioDef != null)) {
			if (EcoreUtil.isAncestor(this, newScenarioDef))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newScenarioDef != null)
				msgs = ((InternalEObject)newScenarioDef).eInverseAdd(this, Standardized_problemPackage.SCENARIO_DEF__TUPLE, ScenarioDef.class, msgs);
			msgs = basicSetScenarioDef(newScenarioDef, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.TUPLE__SCENARIO_DEF, newScenarioDef, newScenarioDef));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationServiceDefinition getCommServiceDef() {
		if (commServiceDef != null && commServiceDef.eIsProxy()) {
			InternalEObject oldCommServiceDef = (InternalEObject)commServiceDef;
			commServiceDef = (CommunicationServiceDefinition)eResolveProxy(oldCommServiceDef);
			if (commServiceDef != oldCommServiceDef) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Standardized_problemPackage.TUPLE__COMM_SERVICE_DEF, oldCommServiceDef, commServiceDef));
			}
		}
		return commServiceDef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationServiceDefinition basicGetCommServiceDef() {
		return commServiceDef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCommServiceDef(CommunicationServiceDefinition newCommServiceDef) {
		CommunicationServiceDefinition oldCommServiceDef = commServiceDef;
		commServiceDef = newCommServiceDef;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.TUPLE__COMM_SERVICE_DEF, oldCommServiceDef, commServiceDef));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal getWeight() {
		return weight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWeight(BigDecimal newWeight) {
		BigDecimal oldWeight = weight;
		weight = newWeight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.TUPLE__WEIGHT, oldWeight, weight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationObject getCommObject() {
		if (commObject != null && commObject.eIsProxy()) {
			InternalEObject oldCommObject = (InternalEObject)commObject;
			commObject = (CommunicationObject)eResolveProxy(oldCommObject);
			if (commObject != oldCommObject) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Standardized_problemPackage.TUPLE__COMM_OBJECT, oldCommObject, commObject));
			}
		}
		return commObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationObject basicGetCommObject() {
		return commObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCommObject(CommunicationObject newCommObject) {
		CommunicationObject oldCommObject = commObject;
		commObject = newCommObject;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.TUPLE__COMM_OBJECT, oldCommObject, commObject));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<WeightedPerfMeasure> getWeightedperfmeasure() {
		if (weightedperfmeasure == null) {
			weightedperfmeasure = new EObjectResolvingEList<WeightedPerfMeasure>(WeightedPerfMeasure.class, this, Standardized_problemPackage.TUPLE__WEIGHTEDPERFMEASURE);
		}
		return weightedperfmeasure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EnvVarVal> getEnvVarVal() {
		if (envVarVal == null) {
			envVarVal = new EObjectContainmentEList<EnvVarVal>(EnvVarVal.class, this, Standardized_problemPackage.TUPLE__ENV_VAR_VAL);
		}
		return envVarVal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Standardized_problemPackage.TUPLE__SCENARIO_DEF:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetScenarioDef((ScenarioDef)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Standardized_problemPackage.TUPLE__SCENARIO_DEF:
				return basicSetScenarioDef(null, msgs);
			case Standardized_problemPackage.TUPLE__ENV_VAR_VAL:
				return ((InternalEList<?>)getEnvVarVal()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case Standardized_problemPackage.TUPLE__SCENARIO_DEF:
				return eInternalContainer().eInverseRemove(this, Standardized_problemPackage.SCENARIO_DEF__TUPLE, ScenarioDef.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Standardized_problemPackage.TUPLE__SCENARIO_DEF:
				return getScenarioDef();
			case Standardized_problemPackage.TUPLE__COMM_SERVICE_DEF:
				if (resolve) return getCommServiceDef();
				return basicGetCommServiceDef();
			case Standardized_problemPackage.TUPLE__WEIGHT:
				return getWeight();
			case Standardized_problemPackage.TUPLE__COMM_OBJECT:
				if (resolve) return getCommObject();
				return basicGetCommObject();
			case Standardized_problemPackage.TUPLE__WEIGHTEDPERFMEASURE:
				return getWeightedperfmeasure();
			case Standardized_problemPackage.TUPLE__ENV_VAR_VAL:
				return getEnvVarVal();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Standardized_problemPackage.TUPLE__SCENARIO_DEF:
				setScenarioDef((ScenarioDef)newValue);
				return;
			case Standardized_problemPackage.TUPLE__COMM_SERVICE_DEF:
				setCommServiceDef((CommunicationServiceDefinition)newValue);
				return;
			case Standardized_problemPackage.TUPLE__WEIGHT:
				setWeight((BigDecimal)newValue);
				return;
			case Standardized_problemPackage.TUPLE__COMM_OBJECT:
				setCommObject((CommunicationObject)newValue);
				return;
			case Standardized_problemPackage.TUPLE__WEIGHTEDPERFMEASURE:
				getWeightedperfmeasure().clear();
				getWeightedperfmeasure().addAll((Collection<? extends WeightedPerfMeasure>)newValue);
				return;
			case Standardized_problemPackage.TUPLE__ENV_VAR_VAL:
				getEnvVarVal().clear();
				getEnvVarVal().addAll((Collection<? extends EnvVarVal>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.TUPLE__SCENARIO_DEF:
				setScenarioDef((ScenarioDef)null);
				return;
			case Standardized_problemPackage.TUPLE__COMM_SERVICE_DEF:
				setCommServiceDef((CommunicationServiceDefinition)null);
				return;
			case Standardized_problemPackage.TUPLE__WEIGHT:
				setWeight(WEIGHT_EDEFAULT);
				return;
			case Standardized_problemPackage.TUPLE__COMM_OBJECT:
				setCommObject((CommunicationObject)null);
				return;
			case Standardized_problemPackage.TUPLE__WEIGHTEDPERFMEASURE:
				getWeightedperfmeasure().clear();
				return;
			case Standardized_problemPackage.TUPLE__ENV_VAR_VAL:
				getEnvVarVal().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.TUPLE__SCENARIO_DEF:
				return getScenarioDef() != null;
			case Standardized_problemPackage.TUPLE__COMM_SERVICE_DEF:
				return commServiceDef != null;
			case Standardized_problemPackage.TUPLE__WEIGHT:
				return WEIGHT_EDEFAULT == null ? weight != null : !WEIGHT_EDEFAULT.equals(weight);
			case Standardized_problemPackage.TUPLE__COMM_OBJECT:
				return commObject != null;
			case Standardized_problemPackage.TUPLE__WEIGHTEDPERFMEASURE:
				return weightedperfmeasure != null && !weightedperfmeasure.isEmpty();
			case Standardized_problemPackage.TUPLE__ENV_VAR_VAL:
				return envVarVal != null && !envVarVal.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (weight: ");
		result.append(weight);
		result.append(')');
		return result.toString();
	}

} //TupleImpl
