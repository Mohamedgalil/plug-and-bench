/**
 */
package standardized_problem.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.ecore.base.basicAttributes.BasicAttributesPackage;

import org.ecore.base.stateMachine.StateMachinePackage;

import org.ecore.service.communicationObject.CommunicationObjectPackage;

import org.ecore.service.communicationPattern.CommunicationPatternPackage;

import org.ecore.service.componentMode.ComponentModePackage;

import org.ecore.service.coordinationPattern.CoordinationPatternPackage;

import org.ecore.service.parameterDefinition.ParameterDefinitionPackage;

import org.ecore.service.serviceDefinition.ServiceDefinitionPackage;

import standardized_problem.BenchmarkConstraint;
import standardized_problem.DescriptorObject;
import standardized_problem.EnvVarVal;
import standardized_problem.EnvironmentVariable;
import standardized_problem.IScore;
import standardized_problem.IScoreElement;
import standardized_problem.PerformanceMeasure;
import standardized_problem.ScenarioDef;
import standardized_problem.StandardizedProblem;
import standardized_problem.Standardized_problemFactory;
import standardized_problem.Standardized_problemPackage;
import standardized_problem.Tuple;
import standardized_problem.WeightedPerfMeasure;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Standardized_problemPackageImpl extends EPackageImpl implements Standardized_problemPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass standardizedProblemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass scenarioDefEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass performanceMeasureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass descriptorObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass environmentVariableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass iScoreElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass iScoreEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tupleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass weightedPerfMeasureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass envVarValEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass benchmarkConstraintEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see standardized_problem.Standardized_problemPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Standardized_problemPackageImpl() {
		super(eNS_URI, Standardized_problemFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Standardized_problemPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Standardized_problemPackage init() {
		if (isInited) return (Standardized_problemPackage)EPackage.Registry.INSTANCE.getEPackage(Standardized_problemPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredStandardized_problemPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		Standardized_problemPackageImpl theStandardized_problemPackage = registeredStandardized_problemPackage instanceof Standardized_problemPackageImpl ? (Standardized_problemPackageImpl)registeredStandardized_problemPackage : new Standardized_problemPackageImpl();

		isInited = true;

		// Initialize simple dependencies
		BasicAttributesPackage.eINSTANCE.eClass();
		CommunicationObjectPackage.eINSTANCE.eClass();
		CommunicationPatternPackage.eINSTANCE.eClass();
		ComponentModePackage.eINSTANCE.eClass();
		CoordinationPatternPackage.eINSTANCE.eClass();
		ParameterDefinitionPackage.eINSTANCE.eClass();
		ServiceDefinitionPackage.eINSTANCE.eClass();
		StateMachinePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theStandardized_problemPackage.createPackageContents();

		// Initialize created meta-data
		theStandardized_problemPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theStandardized_problemPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Standardized_problemPackage.eNS_URI, theStandardized_problemPackage);
		return theStandardized_problemPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStandardizedProblem() {
		return standardizedProblemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStandardizedProblem_ScenarioDefinitions() {
		return (EReference)standardizedProblemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStandardizedProblem_PerformanceCriteria() {
		return (EReference)standardizedProblemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStandardizedProblem_CommServiceDef() {
		return (EReference)standardizedProblemEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getScenarioDef() {
		return scenarioDefEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenarioDef_Dimensions() {
		return (EReference)scenarioDefEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenarioDef_CommServDef() {
		return (EReference)scenarioDefEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getScenarioDef_Weight() {
		return (EAttribute)scenarioDefEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenarioDef_AttributeDefinition() {
		return (EReference)scenarioDefEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenarioDef_Tuple() {
		return (EReference)scenarioDefEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenarioDef_PerformanceMeasures() {
		return (EReference)scenarioDefEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getScenarioDef_Benchmarkconstraint() {
		return (EReference)scenarioDefEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPerformanceMeasure() {
		return performanceMeasureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPerformanceMeasure_Metric() {
		return (EAttribute)performanceMeasureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDescriptorObject() {
		return descriptorObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDescriptorObject_Label() {
		return (EAttribute)descriptorObjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDescriptorObject_Description() {
		return (EAttribute)descriptorObjectEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnvironmentVariable() {
		return environmentVariableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnvironmentVariable_Description() {
		return (EAttribute)environmentVariableEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIScoreElement() {
		return iScoreElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIScoreElement_Score() {
		return (EAttribute)iScoreElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIScore() {
		return iScoreEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getIScore__CalcScore__IScoreElement() {
		return iScoreEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTuple() {
		return tupleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTuple_ScenarioDef() {
		return (EReference)tupleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTuple_CommServiceDef() {
		return (EReference)tupleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTuple_Weight() {
		return (EAttribute)tupleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTuple_CommObject() {
		return (EReference)tupleEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTuple_Weightedperfmeasure() {
		return (EReference)tupleEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTuple_EnvVarVal() {
		return (EReference)tupleEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWeightedPerfMeasure() {
		return weightedPerfMeasureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWeightedPerfMeasure_Weight() {
		return (EAttribute)weightedPerfMeasureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWeightedPerfMeasure_PerfMeasure() {
		return (EReference)weightedPerfMeasureEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnvVarVal() {
		return envVarValEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEnvVarVal_Value() {
		return (EReference)envVarValEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEnvVarVal_EnvironmentVariable() {
		return (EReference)envVarValEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBenchmarkConstraint() {
		return benchmarkConstraintEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBenchmarkConstraint_Description() {
		return (EAttribute)benchmarkConstraintEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Standardized_problemFactory getStandardized_problemFactory() {
		return (Standardized_problemFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		standardizedProblemEClass = createEClass(STANDARDIZED_PROBLEM);
		createEReference(standardizedProblemEClass, STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS);
		createEReference(standardizedProblemEClass, STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA);
		createEReference(standardizedProblemEClass, STANDARDIZED_PROBLEM__COMM_SERVICE_DEF);

		scenarioDefEClass = createEClass(SCENARIO_DEF);
		createEReference(scenarioDefEClass, SCENARIO_DEF__DIMENSIONS);
		createEReference(scenarioDefEClass, SCENARIO_DEF__COMM_SERV_DEF);
		createEAttribute(scenarioDefEClass, SCENARIO_DEF__WEIGHT);
		createEReference(scenarioDefEClass, SCENARIO_DEF__ATTRIBUTE_DEFINITION);
		createEReference(scenarioDefEClass, SCENARIO_DEF__TUPLE);
		createEReference(scenarioDefEClass, SCENARIO_DEF__PERFORMANCE_MEASURES);
		createEReference(scenarioDefEClass, SCENARIO_DEF__BENCHMARKCONSTRAINT);

		performanceMeasureEClass = createEClass(PERFORMANCE_MEASURE);
		createEAttribute(performanceMeasureEClass, PERFORMANCE_MEASURE__METRIC);

		descriptorObjectEClass = createEClass(DESCRIPTOR_OBJECT);
		createEAttribute(descriptorObjectEClass, DESCRIPTOR_OBJECT__LABEL);
		createEAttribute(descriptorObjectEClass, DESCRIPTOR_OBJECT__DESCRIPTION);

		environmentVariableEClass = createEClass(ENVIRONMENT_VARIABLE);
		createEAttribute(environmentVariableEClass, ENVIRONMENT_VARIABLE__DESCRIPTION);

		iScoreElementEClass = createEClass(ISCORE_ELEMENT);
		createEAttribute(iScoreElementEClass, ISCORE_ELEMENT__SCORE);

		iScoreEClass = createEClass(ISCORE);
		createEOperation(iScoreEClass, ISCORE___CALC_SCORE__ISCOREELEMENT);

		tupleEClass = createEClass(TUPLE);
		createEReference(tupleEClass, TUPLE__SCENARIO_DEF);
		createEReference(tupleEClass, TUPLE__COMM_SERVICE_DEF);
		createEAttribute(tupleEClass, TUPLE__WEIGHT);
		createEReference(tupleEClass, TUPLE__COMM_OBJECT);
		createEReference(tupleEClass, TUPLE__WEIGHTEDPERFMEASURE);
		createEReference(tupleEClass, TUPLE__ENV_VAR_VAL);

		weightedPerfMeasureEClass = createEClass(WEIGHTED_PERF_MEASURE);
		createEAttribute(weightedPerfMeasureEClass, WEIGHTED_PERF_MEASURE__WEIGHT);
		createEReference(weightedPerfMeasureEClass, WEIGHTED_PERF_MEASURE__PERF_MEASURE);

		envVarValEClass = createEClass(ENV_VAR_VAL);
		createEReference(envVarValEClass, ENV_VAR_VAL__VALUE);
		createEReference(envVarValEClass, ENV_VAR_VAL__ENVIRONMENT_VARIABLE);

		benchmarkConstraintEClass = createEClass(BENCHMARK_CONSTRAINT);
		createEAttribute(benchmarkConstraintEClass, BENCHMARK_CONSTRAINT__DESCRIPTION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		ServiceDefinitionPackage theServiceDefinitionPackage = (ServiceDefinitionPackage)EPackage.Registry.INSTANCE.getEPackage(ServiceDefinitionPackage.eNS_URI);
		BasicAttributesPackage theBasicAttributesPackage = (BasicAttributesPackage)EPackage.Registry.INSTANCE.getEPackage(BasicAttributesPackage.eNS_URI);
		CommunicationObjectPackage theCommunicationObjectPackage = (CommunicationObjectPackage)EPackage.Registry.INSTANCE.getEPackage(CommunicationObjectPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		standardizedProblemEClass.getESuperTypes().add(this.getDescriptorObject());
		standardizedProblemEClass.getESuperTypes().add(this.getIScoreElement());
		standardizedProblemEClass.getESuperTypes().add(this.getIScore());
		scenarioDefEClass.getESuperTypes().add(this.getDescriptorObject());
		scenarioDefEClass.getESuperTypes().add(this.getIScoreElement());
		scenarioDefEClass.getESuperTypes().add(this.getIScore());
		performanceMeasureEClass.getESuperTypes().add(this.getDescriptorObject());
		environmentVariableEClass.getESuperTypes().add(theBasicAttributesPackage.getAttributeDefinition());
		tupleEClass.getESuperTypes().add(this.getDescriptorObject());
		benchmarkConstraintEClass.getESuperTypes().add(theBasicAttributesPackage.getAttributeDefinition());

		// Initialize classes, features, and operations; add parameters
		initEClass(standardizedProblemEClass, StandardizedProblem.class, "StandardizedProblem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getStandardizedProblem_ScenarioDefinitions(), this.getScenarioDef(), null, "ScenarioDefinitions", null, 1, -1, StandardizedProblem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStandardizedProblem_PerformanceCriteria(), this.getPerformanceMeasure(), null, "performanceCriteria", null, 1, -1, StandardizedProblem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStandardizedProblem_CommServiceDef(), theServiceDefinitionPackage.getCommunicationServiceDefinition(), null, "commServiceDef", null, 0, -1, StandardizedProblem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(scenarioDefEClass, ScenarioDef.class, "ScenarioDef", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getScenarioDef_Dimensions(), this.getEnvironmentVariable(), null, "dimensions", null, 0, -1, ScenarioDef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getScenarioDef_CommServDef(), theServiceDefinitionPackage.getCommunicationServiceDefinition(), null, "commServDef", null, 0, -1, ScenarioDef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getScenarioDef_Weight(), ecorePackage.getEBigDecimal(), "weight", "1.0", 0, 1, ScenarioDef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getScenarioDef_AttributeDefinition(), theBasicAttributesPackage.getAttributeDefinition(), null, "attributeDefinition", null, 0, -1, ScenarioDef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getScenarioDef_Tuple(), this.getTuple(), this.getTuple_ScenarioDef(), "tuple", null, 0, -1, ScenarioDef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getScenarioDef_PerformanceMeasures(), this.getWeightedPerfMeasure(), null, "performanceMeasures", null, 0, -1, ScenarioDef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getScenarioDef_Benchmarkconstraint(), this.getBenchmarkConstraint(), null, "benchmarkconstraint", null, 0, -1, ScenarioDef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(performanceMeasureEClass, PerformanceMeasure.class, "PerformanceMeasure", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPerformanceMeasure_Metric(), ecorePackage.getEString(), "metric", null, 0, 1, PerformanceMeasure.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(descriptorObjectEClass, DescriptorObject.class, "DescriptorObject", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDescriptorObject_Label(), ecorePackage.getEString(), "label", null, 0, 1, DescriptorObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDescriptorObject_Description(), ecorePackage.getEString(), "description", null, 0, 1, DescriptorObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(environmentVariableEClass, EnvironmentVariable.class, "EnvironmentVariable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEnvironmentVariable_Description(), ecorePackage.getEString(), "description", null, 0, 1, EnvironmentVariable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(iScoreElementEClass, IScoreElement.class, "IScoreElement", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIScoreElement_Score(), ecorePackage.getEBigDecimal(), "score", null, 0, 1, IScoreElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(iScoreEClass, IScore.class, "IScore", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		EOperation op = initEOperation(getIScore__CalcScore__IScoreElement(), ecorePackage.getEBigDecimal(), "calcScore", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, this.getIScoreElement(), "scoreElement", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(tupleEClass, Tuple.class, "Tuple", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTuple_ScenarioDef(), this.getScenarioDef(), this.getScenarioDef_Tuple(), "scenarioDef", null, 1, 1, Tuple.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTuple_CommServiceDef(), theServiceDefinitionPackage.getCommunicationServiceDefinition(), null, "commServiceDef", null, 0, 1, Tuple.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTuple_Weight(), ecorePackage.getEBigDecimal(), "weight", "1.0", 0, 1, Tuple.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTuple_CommObject(), theCommunicationObjectPackage.getCommunicationObject(), null, "commObject", null, 0, 1, Tuple.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTuple_Weightedperfmeasure(), this.getWeightedPerfMeasure(), null, "weightedperfmeasure", null, 0, -1, Tuple.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTuple_EnvVarVal(), this.getEnvVarVal(), null, "envVarVal", null, 0, -1, Tuple.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(weightedPerfMeasureEClass, WeightedPerfMeasure.class, "WeightedPerfMeasure", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getWeightedPerfMeasure_Weight(), ecorePackage.getEBigDecimal(), "weight", "1.0", 0, 1, WeightedPerfMeasure.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWeightedPerfMeasure_PerfMeasure(), this.getPerformanceMeasure(), null, "perfMeasure", null, 1, 1, WeightedPerfMeasure.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(envVarValEClass, EnvVarVal.class, "EnvVarVal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEnvVarVal_Value(), theBasicAttributesPackage.getAbstractValue(), null, "value", null, 0, 1, EnvVarVal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEnvVarVal_EnvironmentVariable(), this.getEnvironmentVariable(), null, "environmentVariable", null, 1, 1, EnvVarVal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(benchmarkConstraintEClass, BenchmarkConstraint.class, "BenchmarkConstraint", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getBenchmarkConstraint_Description(), ecorePackage.getEString(), "description", null, 0, 1, BenchmarkConstraint.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/OCL/Import
		createImportAnnotations();
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Import</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createImportAnnotations() {
		String source = "http://www.eclipse.org/OCL/Import";
		addAnnotation
		  (this,
		   source,
		   new String[] {
			   "BasicAttributes", "../../org.ecore.base.basicAttributes/model/basicAttributes.ecore#/",
			   "CommunicationObject_0", "../../org.ecore.service.communicationObject/model/communicationObject.ecore#/",
			   "ComponentDefinition_0", "../../org.ecore.component.componentDefinition/model/componentDefinition.ecore#/",
			   "ServiceDefinition", "../../org.ecore.service.serviceDefinition/model/serviceDefinition.ecore#/",
			   "ecore", "http://www.eclipse.org/emf/2002/Ecore"
		   });
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation
		  (standardizedProblemEClass,
		   source,
		   new String[] {
			   "name", "elements"
		   });
		addAnnotation
		  (scenarioDefEClass,
		   source,
		   new String[] {
			   "name", "elements"
		   });
		addAnnotation
		  (performanceMeasureEClass,
		   source,
		   new String[] {
			   "name", "elements"
		   });
	}

} //Standardized_problemPackageImpl
