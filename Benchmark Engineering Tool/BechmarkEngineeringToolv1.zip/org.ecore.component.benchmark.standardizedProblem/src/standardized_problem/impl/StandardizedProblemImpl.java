/**
 */
package standardized_problem.impl;

import java.lang.reflect.InvocationTargetException;

import java.math.BigDecimal;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.ecore.service.serviceDefinition.CommunicationServiceDefinition;

import standardized_problem.IScore;
import standardized_problem.IScoreElement;
import standardized_problem.PerformanceMeasure;
import standardized_problem.ScenarioDef;
import standardized_problem.StandardizedProblem;
import standardized_problem.Standardized_problemPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Standardized Problem</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.impl.StandardizedProblemImpl#getScore <em>Score</em>}</li>
 *   <li>{@link standardized_problem.impl.StandardizedProblemImpl#getScenarioDefinitions <em>Scenario Definitions</em>}</li>
 *   <li>{@link standardized_problem.impl.StandardizedProblemImpl#getPerformanceCriteria <em>Performance Criteria</em>}</li>
 *   <li>{@link standardized_problem.impl.StandardizedProblemImpl#getCommServiceDef <em>Comm Service Def</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StandardizedProblemImpl extends DescriptorObjectImpl implements StandardizedProblem {
	/**
	 * The default value of the '{@link #getScore() <em>Score</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScore()
	 * @generated
	 * @ordered
	 */
	protected static final BigDecimal SCORE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getScore() <em>Score</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScore()
	 * @generated
	 * @ordered
	 */
	protected BigDecimal score = SCORE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getScenarioDefinitions() <em>Scenario Definitions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScenarioDefinitions()
	 * @generated
	 * @ordered
	 */
	protected EList<ScenarioDef> scenarioDefinitions;

	/**
	 * The cached value of the '{@link #getPerformanceCriteria() <em>Performance Criteria</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPerformanceCriteria()
	 * @generated
	 * @ordered
	 */
	protected EList<PerformanceMeasure> performanceCriteria;

	/**
	 * The cached value of the '{@link #getCommServiceDef() <em>Comm Service Def</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommServiceDef()
	 * @generated
	 * @ordered
	 */
	protected EList<CommunicationServiceDefinition> commServiceDef;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StandardizedProblemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Standardized_problemPackage.Literals.STANDARDIZED_PROBLEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal getScore() {
		return score;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScore(BigDecimal newScore) {
		BigDecimal oldScore = score;
		score = newScore;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.STANDARDIZED_PROBLEM__SCORE, oldScore, score));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ScenarioDef> getScenarioDefinitions() {
		if (scenarioDefinitions == null) {
			scenarioDefinitions = new EObjectContainmentEList<ScenarioDef>(ScenarioDef.class, this, Standardized_problemPackage.STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS);
		}
		return scenarioDefinitions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PerformanceMeasure> getPerformanceCriteria() {
		if (performanceCriteria == null) {
			performanceCriteria = new EObjectContainmentEList<PerformanceMeasure>(PerformanceMeasure.class, this, Standardized_problemPackage.STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA);
		}
		return performanceCriteria;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CommunicationServiceDefinition> getCommServiceDef() {
		if (commServiceDef == null) {
			commServiceDef = new EObjectResolvingEList<CommunicationServiceDefinition>(CommunicationServiceDefinition.class, this, Standardized_problemPackage.STANDARDIZED_PROBLEM__COMM_SERVICE_DEF);
		}
		return commServiceDef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal calcScore(IScoreElement scoreElement) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS:
				return ((InternalEList<?>)getScenarioDefinitions()).basicRemove(otherEnd, msgs);
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA:
				return ((InternalEList<?>)getPerformanceCriteria()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCORE:
				return getScore();
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS:
				return getScenarioDefinitions();
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA:
				return getPerformanceCriteria();
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__COMM_SERVICE_DEF:
				return getCommServiceDef();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCORE:
				setScore((BigDecimal)newValue);
				return;
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS:
				getScenarioDefinitions().clear();
				getScenarioDefinitions().addAll((Collection<? extends ScenarioDef>)newValue);
				return;
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA:
				getPerformanceCriteria().clear();
				getPerformanceCriteria().addAll((Collection<? extends PerformanceMeasure>)newValue);
				return;
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__COMM_SERVICE_DEF:
				getCommServiceDef().clear();
				getCommServiceDef().addAll((Collection<? extends CommunicationServiceDefinition>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCORE:
				setScore(SCORE_EDEFAULT);
				return;
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS:
				getScenarioDefinitions().clear();
				return;
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA:
				getPerformanceCriteria().clear();
				return;
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__COMM_SERVICE_DEF:
				getCommServiceDef().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCORE:
				return SCORE_EDEFAULT == null ? score != null : !SCORE_EDEFAULT.equals(score);
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCENARIO_DEFINITIONS:
				return scenarioDefinitions != null && !scenarioDefinitions.isEmpty();
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__PERFORMANCE_CRITERIA:
				return performanceCriteria != null && !performanceCriteria.isEmpty();
			case Standardized_problemPackage.STANDARDIZED_PROBLEM__COMM_SERVICE_DEF:
				return commServiceDef != null && !commServiceDef.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == IScoreElement.class) {
			switch (derivedFeatureID) {
				case Standardized_problemPackage.STANDARDIZED_PROBLEM__SCORE: return Standardized_problemPackage.ISCORE_ELEMENT__SCORE;
				default: return -1;
			}
		}
		if (baseClass == IScore.class) {
			switch (derivedFeatureID) {
				default: return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == IScoreElement.class) {
			switch (baseFeatureID) {
				case Standardized_problemPackage.ISCORE_ELEMENT__SCORE: return Standardized_problemPackage.STANDARDIZED_PROBLEM__SCORE;
				default: return -1;
			}
		}
		if (baseClass == IScore.class) {
			switch (baseFeatureID) {
				default: return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedOperationID(int baseOperationID, Class<?> baseClass) {
		if (baseClass == IScoreElement.class) {
			switch (baseOperationID) {
				default: return -1;
			}
		}
		if (baseClass == IScore.class) {
			switch (baseOperationID) {
				case Standardized_problemPackage.ISCORE___CALC_SCORE__ISCOREELEMENT: return Standardized_problemPackage.STANDARDIZED_PROBLEM___CALC_SCORE__ISCOREELEMENT;
				default: return -1;
			}
		}
		return super.eDerivedOperationID(baseOperationID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Standardized_problemPackage.STANDARDIZED_PROBLEM___CALC_SCORE__ISCOREELEMENT:
				return calcScore((IScoreElement)arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (score: ");
		result.append(score);
		result.append(')');
		return result.toString();
	}

} //StandardizedProblemImpl
