/**
 */
package standardized_problem.impl;

import java.lang.reflect.InvocationTargetException;

import java.math.BigDecimal;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.ecore.base.basicAttributes.AttributeDefinition;

import org.ecore.service.serviceDefinition.CommunicationServiceDefinition;

import standardized_problem.BenchmarkConstraint;
import standardized_problem.EnvironmentVariable;
import standardized_problem.IScore;
import standardized_problem.IScoreElement;
import standardized_problem.ScenarioDef;
import standardized_problem.Standardized_problemPackage;
import standardized_problem.Tuple;
import standardized_problem.WeightedPerfMeasure;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Scenario Def</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.impl.ScenarioDefImpl#getScore <em>Score</em>}</li>
 *   <li>{@link standardized_problem.impl.ScenarioDefImpl#getDimensions <em>Dimensions</em>}</li>
 *   <li>{@link standardized_problem.impl.ScenarioDefImpl#getCommServDef <em>Comm Serv Def</em>}</li>
 *   <li>{@link standardized_problem.impl.ScenarioDefImpl#getWeight <em>Weight</em>}</li>
 *   <li>{@link standardized_problem.impl.ScenarioDefImpl#getAttributeDefinition <em>Attribute Definition</em>}</li>
 *   <li>{@link standardized_problem.impl.ScenarioDefImpl#getTuple <em>Tuple</em>}</li>
 *   <li>{@link standardized_problem.impl.ScenarioDefImpl#getPerformanceMeasures <em>Performance Measures</em>}</li>
 *   <li>{@link standardized_problem.impl.ScenarioDefImpl#getBenchmarkconstraint <em>Benchmarkconstraint</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ScenarioDefImpl extends DescriptorObjectImpl implements ScenarioDef {
	/**
	 * The default value of the '{@link #getScore() <em>Score</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScore()
	 * @generated
	 * @ordered
	 */
	protected static final BigDecimal SCORE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getScore() <em>Score</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScore()
	 * @generated
	 * @ordered
	 */
	protected BigDecimal score = SCORE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDimensions() <em>Dimensions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDimensions()
	 * @generated
	 * @ordered
	 */
	protected EList<EnvironmentVariable> dimensions;

	/**
	 * The cached value of the '{@link #getCommServDef() <em>Comm Serv Def</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommServDef()
	 * @generated
	 * @ordered
	 */
	protected EList<CommunicationServiceDefinition> commServDef;

	/**
	 * The default value of the '{@link #getWeight() <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeight()
	 * @generated
	 * @ordered
	 */
	protected static final BigDecimal WEIGHT_EDEFAULT = new BigDecimal("1.0");

	/**
	 * The cached value of the '{@link #getWeight() <em>Weight</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeight()
	 * @generated
	 * @ordered
	 */
	protected BigDecimal weight = WEIGHT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAttributeDefinition() <em>Attribute Definition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributeDefinition()
	 * @generated
	 * @ordered
	 */
	protected EList<AttributeDefinition> attributeDefinition;

	/**
	 * The cached value of the '{@link #getTuple() <em>Tuple</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTuple()
	 * @generated
	 * @ordered
	 */
	protected EList<Tuple> tuple;

	/**
	 * The cached value of the '{@link #getPerformanceMeasures() <em>Performance Measures</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPerformanceMeasures()
	 * @generated
	 * @ordered
	 */
	protected EList<WeightedPerfMeasure> performanceMeasures;

	/**
	 * The cached value of the '{@link #getBenchmarkconstraint() <em>Benchmarkconstraint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBenchmarkconstraint()
	 * @generated
	 * @ordered
	 */
	protected EList<BenchmarkConstraint> benchmarkconstraint;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ScenarioDefImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Standardized_problemPackage.Literals.SCENARIO_DEF;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal getScore() {
		return score;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScore(BigDecimal newScore) {
		BigDecimal oldScore = score;
		score = newScore;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.SCENARIO_DEF__SCORE, oldScore, score));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EnvironmentVariable> getDimensions() {
		if (dimensions == null) {
			dimensions = new EObjectContainmentEList<EnvironmentVariable>(EnvironmentVariable.class, this, Standardized_problemPackage.SCENARIO_DEF__DIMENSIONS);
		}
		return dimensions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CommunicationServiceDefinition> getCommServDef() {
		if (commServDef == null) {
			commServDef = new EObjectResolvingEList<CommunicationServiceDefinition>(CommunicationServiceDefinition.class, this, Standardized_problemPackage.SCENARIO_DEF__COMM_SERV_DEF);
		}
		return commServDef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal getWeight() {
		return weight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWeight(BigDecimal newWeight) {
		BigDecimal oldWeight = weight;
		weight = newWeight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Standardized_problemPackage.SCENARIO_DEF__WEIGHT, oldWeight, weight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AttributeDefinition> getAttributeDefinition() {
		if (attributeDefinition == null) {
			attributeDefinition = new EObjectResolvingEList<AttributeDefinition>(AttributeDefinition.class, this, Standardized_problemPackage.SCENARIO_DEF__ATTRIBUTE_DEFINITION);
		}
		return attributeDefinition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Tuple> getTuple() {
		if (tuple == null) {
			tuple = new EObjectContainmentWithInverseEList<Tuple>(Tuple.class, this, Standardized_problemPackage.SCENARIO_DEF__TUPLE, Standardized_problemPackage.TUPLE__SCENARIO_DEF);
		}
		return tuple;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<WeightedPerfMeasure> getPerformanceMeasures() {
		if (performanceMeasures == null) {
			performanceMeasures = new EObjectContainmentEList<WeightedPerfMeasure>(WeightedPerfMeasure.class, this, Standardized_problemPackage.SCENARIO_DEF__PERFORMANCE_MEASURES);
		}
		return performanceMeasures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BenchmarkConstraint> getBenchmarkconstraint() {
		if (benchmarkconstraint == null) {
			benchmarkconstraint = new EObjectContainmentEList<BenchmarkConstraint>(BenchmarkConstraint.class, this, Standardized_problemPackage.SCENARIO_DEF__BENCHMARKCONSTRAINT);
		}
		return benchmarkconstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal calcScore(IScoreElement scoreElement) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Standardized_problemPackage.SCENARIO_DEF__TUPLE:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getTuple()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Standardized_problemPackage.SCENARIO_DEF__DIMENSIONS:
				return ((InternalEList<?>)getDimensions()).basicRemove(otherEnd, msgs);
			case Standardized_problemPackage.SCENARIO_DEF__TUPLE:
				return ((InternalEList<?>)getTuple()).basicRemove(otherEnd, msgs);
			case Standardized_problemPackage.SCENARIO_DEF__PERFORMANCE_MEASURES:
				return ((InternalEList<?>)getPerformanceMeasures()).basicRemove(otherEnd, msgs);
			case Standardized_problemPackage.SCENARIO_DEF__BENCHMARKCONSTRAINT:
				return ((InternalEList<?>)getBenchmarkconstraint()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Standardized_problemPackage.SCENARIO_DEF__SCORE:
				return getScore();
			case Standardized_problemPackage.SCENARIO_DEF__DIMENSIONS:
				return getDimensions();
			case Standardized_problemPackage.SCENARIO_DEF__COMM_SERV_DEF:
				return getCommServDef();
			case Standardized_problemPackage.SCENARIO_DEF__WEIGHT:
				return getWeight();
			case Standardized_problemPackage.SCENARIO_DEF__ATTRIBUTE_DEFINITION:
				return getAttributeDefinition();
			case Standardized_problemPackage.SCENARIO_DEF__TUPLE:
				return getTuple();
			case Standardized_problemPackage.SCENARIO_DEF__PERFORMANCE_MEASURES:
				return getPerformanceMeasures();
			case Standardized_problemPackage.SCENARIO_DEF__BENCHMARKCONSTRAINT:
				return getBenchmarkconstraint();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Standardized_problemPackage.SCENARIO_DEF__SCORE:
				setScore((BigDecimal)newValue);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__DIMENSIONS:
				getDimensions().clear();
				getDimensions().addAll((Collection<? extends EnvironmentVariable>)newValue);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__COMM_SERV_DEF:
				getCommServDef().clear();
				getCommServDef().addAll((Collection<? extends CommunicationServiceDefinition>)newValue);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__WEIGHT:
				setWeight((BigDecimal)newValue);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__ATTRIBUTE_DEFINITION:
				getAttributeDefinition().clear();
				getAttributeDefinition().addAll((Collection<? extends AttributeDefinition>)newValue);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__TUPLE:
				getTuple().clear();
				getTuple().addAll((Collection<? extends Tuple>)newValue);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__PERFORMANCE_MEASURES:
				getPerformanceMeasures().clear();
				getPerformanceMeasures().addAll((Collection<? extends WeightedPerfMeasure>)newValue);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__BENCHMARKCONSTRAINT:
				getBenchmarkconstraint().clear();
				getBenchmarkconstraint().addAll((Collection<? extends BenchmarkConstraint>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.SCENARIO_DEF__SCORE:
				setScore(SCORE_EDEFAULT);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__DIMENSIONS:
				getDimensions().clear();
				return;
			case Standardized_problemPackage.SCENARIO_DEF__COMM_SERV_DEF:
				getCommServDef().clear();
				return;
			case Standardized_problemPackage.SCENARIO_DEF__WEIGHT:
				setWeight(WEIGHT_EDEFAULT);
				return;
			case Standardized_problemPackage.SCENARIO_DEF__ATTRIBUTE_DEFINITION:
				getAttributeDefinition().clear();
				return;
			case Standardized_problemPackage.SCENARIO_DEF__TUPLE:
				getTuple().clear();
				return;
			case Standardized_problemPackage.SCENARIO_DEF__PERFORMANCE_MEASURES:
				getPerformanceMeasures().clear();
				return;
			case Standardized_problemPackage.SCENARIO_DEF__BENCHMARKCONSTRAINT:
				getBenchmarkconstraint().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Standardized_problemPackage.SCENARIO_DEF__SCORE:
				return SCORE_EDEFAULT == null ? score != null : !SCORE_EDEFAULT.equals(score);
			case Standardized_problemPackage.SCENARIO_DEF__DIMENSIONS:
				return dimensions != null && !dimensions.isEmpty();
			case Standardized_problemPackage.SCENARIO_DEF__COMM_SERV_DEF:
				return commServDef != null && !commServDef.isEmpty();
			case Standardized_problemPackage.SCENARIO_DEF__WEIGHT:
				return WEIGHT_EDEFAULT == null ? weight != null : !WEIGHT_EDEFAULT.equals(weight);
			case Standardized_problemPackage.SCENARIO_DEF__ATTRIBUTE_DEFINITION:
				return attributeDefinition != null && !attributeDefinition.isEmpty();
			case Standardized_problemPackage.SCENARIO_DEF__TUPLE:
				return tuple != null && !tuple.isEmpty();
			case Standardized_problemPackage.SCENARIO_DEF__PERFORMANCE_MEASURES:
				return performanceMeasures != null && !performanceMeasures.isEmpty();
			case Standardized_problemPackage.SCENARIO_DEF__BENCHMARKCONSTRAINT:
				return benchmarkconstraint != null && !benchmarkconstraint.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == IScoreElement.class) {
			switch (derivedFeatureID) {
				case Standardized_problemPackage.SCENARIO_DEF__SCORE: return Standardized_problemPackage.ISCORE_ELEMENT__SCORE;
				default: return -1;
			}
		}
		if (baseClass == IScore.class) {
			switch (derivedFeatureID) {
				default: return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == IScoreElement.class) {
			switch (baseFeatureID) {
				case Standardized_problemPackage.ISCORE_ELEMENT__SCORE: return Standardized_problemPackage.SCENARIO_DEF__SCORE;
				default: return -1;
			}
		}
		if (baseClass == IScore.class) {
			switch (baseFeatureID) {
				default: return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedOperationID(int baseOperationID, Class<?> baseClass) {
		if (baseClass == IScoreElement.class) {
			switch (baseOperationID) {
				default: return -1;
			}
		}
		if (baseClass == IScore.class) {
			switch (baseOperationID) {
				case Standardized_problemPackage.ISCORE___CALC_SCORE__ISCOREELEMENT: return Standardized_problemPackage.SCENARIO_DEF___CALC_SCORE__ISCOREELEMENT;
				default: return -1;
			}
		}
		return super.eDerivedOperationID(baseOperationID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Standardized_problemPackage.SCENARIO_DEF___CALC_SCORE__ISCOREELEMENT:
				return calcScore((IScoreElement)arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (score: ");
		result.append(score);
		result.append(", weight: ");
		result.append(weight);
		result.append(')');
		return result.toString();
	}

} //ScenarioDefImpl
