/**
 */
package standardized_problem.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import standardized_problem.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Standardized_problemFactoryImpl extends EFactoryImpl implements Standardized_problemFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Standardized_problemFactory init() {
		try {
			Standardized_problemFactory theStandardized_problemFactory = (Standardized_problemFactory)EPackage.Registry.INSTANCE.getEFactory(Standardized_problemPackage.eNS_URI);
			if (theStandardized_problemFactory != null) {
				return theStandardized_problemFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Standardized_problemFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Standardized_problemFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case Standardized_problemPackage.STANDARDIZED_PROBLEM: return createStandardizedProblem();
			case Standardized_problemPackage.SCENARIO_DEF: return createScenarioDef();
			case Standardized_problemPackage.PERFORMANCE_MEASURE: return createPerformanceMeasure();
			case Standardized_problemPackage.ENVIRONMENT_VARIABLE: return createEnvironmentVariable();
			case Standardized_problemPackage.TUPLE: return createTuple();
			case Standardized_problemPackage.WEIGHTED_PERF_MEASURE: return createWeightedPerfMeasure();
			case Standardized_problemPackage.ENV_VAR_VAL: return createEnvVarVal();
			case Standardized_problemPackage.BENCHMARK_CONSTRAINT: return createBenchmarkConstraint();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StandardizedProblem createStandardizedProblem() {
		StandardizedProblemImpl standardizedProblem = new StandardizedProblemImpl();
		return standardizedProblem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ScenarioDef createScenarioDef() {
		ScenarioDefImpl scenarioDef = new ScenarioDefImpl();
		return scenarioDef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformanceMeasure createPerformanceMeasure() {
		PerformanceMeasureImpl performanceMeasure = new PerformanceMeasureImpl();
		return performanceMeasure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnvironmentVariable createEnvironmentVariable() {
		EnvironmentVariableImpl environmentVariable = new EnvironmentVariableImpl();
		return environmentVariable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tuple createTuple() {
		TupleImpl tuple = new TupleImpl();
		return tuple;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WeightedPerfMeasure createWeightedPerfMeasure() {
		WeightedPerfMeasureImpl weightedPerfMeasure = new WeightedPerfMeasureImpl();
		return weightedPerfMeasure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnvVarVal createEnvVarVal() {
		EnvVarValImpl envVarVal = new EnvVarValImpl();
		return envVarVal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BenchmarkConstraint createBenchmarkConstraint() {
		BenchmarkConstraintImpl benchmarkConstraint = new BenchmarkConstraintImpl();
		return benchmarkConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Standardized_problemPackage getStandardized_problemPackage() {
		return (Standardized_problemPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Standardized_problemPackage getPackage() {
		return Standardized_problemPackage.eINSTANCE;
	}

} //Standardized_problemFactoryImpl
