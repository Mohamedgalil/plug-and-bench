/**
 */
package standardized_problem;

import org.eclipse.emf.common.util.EList;

import org.ecore.service.serviceDefinition.CommunicationServiceDefinition;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Standardized Problem</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A StandardizedProblem is an attempt to standardize the benchmarking of a given skill (components), in a well-defined environment.
 * 
 * Alternative terms: -
 * - Why Standardized Problem? To satisfy the property of "Comparison" (see _Methodological Foundations for the Benchmark Metamodel_), which states that "Comparison is to know what has been already done in the fiAAAAAAAAAA􏰃eld, to avoid the repetition of uninteresting experiments, and to get hints on promising issues to tackle.")
 * 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.StandardizedProblem#getScenarioDefinitions <em>Scenario Definitions</em>}</li>
 *   <li>{@link standardized_problem.StandardizedProblem#getPerformanceCriteria <em>Performance Criteria</em>}</li>
 *   <li>{@link standardized_problem.StandardizedProblem#getCommServiceDef <em>Comm Service Def</em>}</li>
 * </ul>
 *
 * @see standardized_problem.Standardized_problemPackage#getStandardizedProblem()
 * @model extendedMetaData="name='elements'"
 * @generated
 */
public interface StandardizedProblem extends DescriptorObject, IScoreElement, IScore {
	/**
	 * Returns the value of the '<em><b>Scenario Definitions</b></em>' containment reference list.
	 * The list contents are of type {@link standardized_problem.ScenarioDef}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scenario Definitions</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scenario Definitions</em>' containment reference list.
	 * @see standardized_problem.Standardized_problemPackage#getStandardizedProblem_ScenarioDefinitions()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<ScenarioDef> getScenarioDefinitions();

	/**
	 * Returns the value of the '<em><b>Performance Criteria</b></em>' containment reference list.
	 * The list contents are of type {@link standardized_problem.PerformanceMeasure}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Performance Criteria</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Performance Criteria</em>' containment reference list.
	 * @see standardized_problem.Standardized_problemPackage#getStandardizedProblem_PerformanceCriteria()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<PerformanceMeasure> getPerformanceCriteria();

	/**
	 * Returns the value of the '<em><b>Comm Service Def</b></em>' reference list.
	 * The list contents are of type {@link org.ecore.service.serviceDefinition.CommunicationServiceDefinition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Specifies the CommServiceDefinition to connect to Component to-be-benchmarked.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Comm Service Def</em>' reference list.
	 * @see standardized_problem.Standardized_problemPackage#getStandardizedProblem_CommServiceDef()
	 * @model
	 * @generated
	 */
	EList<CommunicationServiceDefinition> getCommServiceDef();

} // StandardizedProblem
