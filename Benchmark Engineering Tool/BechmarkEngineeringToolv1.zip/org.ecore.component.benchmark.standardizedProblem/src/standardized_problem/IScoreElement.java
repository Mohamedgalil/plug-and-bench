/**
 */
package standardized_problem;

import java.math.BigDecimal;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IScore Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link standardized_problem.IScoreElement#getScore <em>Score</em>}</li>
 * </ul>
 *
 * @see standardized_problem.Standardized_problemPackage#getIScoreElement()
 * @model abstract="true"
 * @generated
 */
public interface IScoreElement extends EObject {
	/**
	 * Returns the value of the '<em><b>Score</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Score</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Score</em>' attribute.
	 * @see #setScore(BigDecimal)
	 * @see standardized_problem.Standardized_problemPackage#getIScoreElement_Score()
	 * @model
	 * @generated
	 */
	BigDecimal getScore();

	/**
	 * Sets the value of the '{@link standardized_problem.IScoreElement#getScore <em>Score</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Score</em>' attribute.
	 * @see #getScore()
	 * @generated
	 */
	void setScore(BigDecimal value);

} // IScoreElement
